package com.tedu.controller;

import com.tedu.manager.ElementManager;
import com.tedu.element.Player;
import com.tedu.element.PlayerMovement;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.List;

public class GameListener implements KeyListener {
	private List<?> players;

	private static final int KEY_A = 65;  // A
	private static final int KEY_W = 87;  // W
	private static final int KEY_D = 68;  // D
	private static final int KEY_S = 83;  // S
	private static final int KEY_SPACE = 32;  // Space
	private static final int KEY_LEFT = 37;  // Left Arrow
	private static final int KEY_UP = 38;  // Up Arrow
	private static final int KEY_RIGHT = 39;  // Right Arrow
	private static final int KEY_DOWN = 40;  // Down Arrow
	private static final int KEY_ENTER = 10;  // Enter

	@Override
	public void keyTyped(KeyEvent e) {
		// No action needed here
	}

	@Override
	public void keyPressed(KeyEvent e) {
		players = ElementManager.getInstance().getElementList("play");
		Player playerOne = (Player) players.get(0);
		Player playerTwo = (Player) players.get(1);

		// Handle player movement based on key press
		handleKeyPress(e.getKeyCode(), playerOne, playerTwo, true);
	}

	@Override
	public void keyReleased(KeyEvent e) {
		players = ElementManager.getInstance().getElementList("play");
		Player playerOne = (Player) players.get(0);
		Player playerTwo = (Player) players.get(1);

		// Handle player movement based on key release
		handleKeyPress(e.getKeyCode(), playerOne, playerTwo, false);
	}

	/**
	 * Handles movement and PK actions for players based on key events.
	 *
	 * @param keyCode The key that was pressed or released.
	 * @param playerOne The first player.
	 * @param playerTwo The second player.
	 * @param isPressed Whether the key is pressed or released.
	 */
	private void handleKeyPress(int keyCode, Player playerOne, Player playerTwo, boolean isPressed) {
		PlayerMovement movementOne = playerOne.getMovement();
		PlayerMovement movementTwo = playerTwo.getMovement();

		switch (keyCode) {
			case KEY_A:  // Player One - Left
				movementOne.setLEFT(isPressed);
				break;
			case KEY_W:  // Player One - Up
				movementOne.setUP(isPressed);
				break;
			case KEY_D:  // Player One - Right
				movementOne.setRIGHT(isPressed);
				break;
			case KEY_S:  // Player One - Down
				movementOne.setDOWN(isPressed);
				break;
			case KEY_SPACE:  // Player One - PK
				playerOne.setPk(isPressed);
				break;
			case KEY_LEFT:  // Player Two - Left
				movementTwo.setLEFT(isPressed);
				break;
			case KEY_UP:  // Player Two - Up
				movementTwo.setUP(isPressed);
				break;
			case KEY_RIGHT:  // Player Two - Right
				movementTwo.setRIGHT(isPressed);
				break;
			case KEY_DOWN:  // Player Two - Down
				movementTwo.setDOWN(isPressed);
				break;
			case KEY_ENTER:  // Player Two - PK
				playerTwo.setPk(isPressed);
				break;
		}
	}
}
