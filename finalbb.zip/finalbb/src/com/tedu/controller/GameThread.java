package com.tedu.controller;

import com.tedu.manager.ElementManager;
import com.tedu.element.Player;
import com.tedu.element.SuperElement;
import com.tedu.element.AudioManager;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;

public class GameThread extends Thread {
	// 计时数据
	private static int time;
	private boolean flag = true;
	private AudioManager audioManager;

	public GameThread() {
		audioManager = AudioManager.getInstance();
	}

	@Override
	public void run() {
		loadElement();

		time = 0;
		loadBGM();
		runGame();
	}

	public void loadElement() {
		// 加载游戏元素
		ElementManager.getInstance().load();
	}

	public void runGame() {
		ElementManager manager = ElementManager.getInstance();

		while (flag) {
			updateGameElements(manager);

			// 处理PK
			handlePK();

			// 游戏流程控制
			linkGame();

			// 控制游戏进度
			sleepGameThread();

			// 游戏结束判定
			overGame();

			time++; // 一秒钟增加10
		}

		// 游戏结束时清理音频资源
		audioManager.stopAllAudios();
	}

	private void updateGameElements(ElementManager manager) {
		Map<String, List<SuperElement>> map = manager.getMap();
		Set<String> set = map.keySet();
		for (String key : set) {
			List<SuperElement> list = map.get(key);
			// 处理每个元素
			updateElementList(list);
		}
	}

	private void updateElementList(List<SuperElement> list) {
		ElementManager manager = ElementManager.getInstance();
		for (int j = list.size() - 1; j >= 0; j--) {
			SuperElement superElement = list.get(j);
			superElement.update();
			if (!superElement.isVisible()) {
				manager.removeElementByPx(superElement.getY(), superElement.getX());
				list.remove(j);
			}
		}
	}

	public void handlePK() {
		List<SuperElement> players = ElementManager.getInstance().getElementList("play");
		List<SuperElement> enemies = ElementManager.getInstance().getElementList("enemylist");

		performPK(players, enemies);
	}

	private void performPK(List<SuperElement> players, List<SuperElement> enemies) {
		for (SuperElement player : players) {
			for (SuperElement enemy : enemies) {
				if (player.gamePK(enemy)) {
					enemy.setVisible(false);
					// 播放爆炸音效
					audioManager.playBoomSound();
				}
			}
		}
	}

	public void overGame() {
		Player player1 = (Player) (ElementManager.getInstance().getElementList("play").get(0));
		Player player2 = (Player) (ElementManager.getInstance().getElementList("play").get(1));

		if (player1.getNum() >= 1000 || player2.getNum() >= 1000) {
			flag = false;
			// 停止背景音乐
			audioManager.stopBackgroundMusic();
			// 播放游戏结束音效
			audioManager.playGameOverSound();
		}
	}

	// 游戏流程控制
	public void linkGame() {
		ElementManager.getInstance().linkGame(time);
	}

	public static int getTime() {
		return time;
	}

	public static void setTime(int time) {
		GameThread.time = time;
	}

	private void loadBGM() {
		// 播放背景音乐（循环播放）
		audioManager.playBGM();
	}

	private void sleepGameThread() {
		try {
			TimeUnit.MILLISECONDS.sleep(100);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	// 停止游戏线程
	public void stopGame() {
		flag = false;
		audioManager.stopAllAudios();
	}

	// 暂停/恢复背景音乐
	public void pauseBGM() {
		audioManager.stopBackgroundMusic();
	}

	public void resumeBGM() {
		if (flag) {
			audioManager.playBGM();
		}
	}

	// 播放坦克诞生音效
	public void playTankSpawnSound() {
		audioManager.playPutSound();
	}

	// 获取音频管理器实例（供其他类使用）
	public AudioManager getAudioManager() {
		return audioManager;
	}
}
