package com.tedu.show;

import java.awt.*;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

import com.tedu.manager.ElementManager;
import com.tedu.manager.ScaleManager;
import com.tedu.element.Player;
import com.tedu.element.SuperElement;

public class MyGameJPanel extends JPanel implements Runnable {
    // 单例管理器
    private ElementManager manager;
    private ScaleManager scaleManager;

    // UI组件
    private JButton restartButton;

    // 游戏状态
    private boolean gameOver = false;
    private volatile boolean running = true;
    private boolean timeUp = false;

    // 时间管理
    private long gameStartTime;
    private static final long GAME_DURATION_MS = 150_000L; // 2.5分钟
    private long remainingTime = GAME_DURATION_MS;

    // 预加载图片资源
    private BufferedImage rightSightImage;
    private BufferedImage bottomImage;
    private BufferedImage gameOverImage;

    // 布局常量 - 基于原始设计尺寸
    private static final int ORIGINAL_GAME_WIDTH = 480;
    private static final int ORIGINAL_GAME_HEIGHT = 480;
    private static final int ORIGINAL_RIGHT_PANEL_WIDTH = 160;
    private static final int ORIGINAL_BOTTOM_PANEL_HEIGHT = 50;
    private static final int ORIGINAL_TOTAL_WIDTH = ORIGINAL_GAME_WIDTH + ORIGINAL_RIGHT_PANEL_WIDTH;
    private static final int ORIGINAL_TOTAL_HEIGHT = ORIGINAL_GAME_HEIGHT + ORIGINAL_BOTTOM_PANEL_HEIGHT;

    // 渲染提示
    private static final RenderingHints RENDERING_HINTS = new RenderingHints(
            RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON
    );

    static {
        RENDERING_HINTS.put(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        RENDERING_HINTS.put(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
    }

    public MyGameJPanel() {
        initializePanel();
        initializeManagers();
        initializeGameTimer();
        loadImageResources();
        createRestartButton();
    }

    private void initializePanel() {
        setLayout(null);
        setDoubleBuffered(true);
        setOpaque(true);
        setBackground(Color.BLACK);
    }

    private void initializeManagers() {
        manager = ElementManager.getInstance();
        scaleManager = ScaleManager.getInstance();
    }

    private void initializeGameTimer() {
        gameStartTime = System.currentTimeMillis();
    }

    @Override
    public void setBounds(int x, int y, int width, int height) {
        super.setBounds(x, y, width, height);
        if (restartButton != null) {
            updateRestartButtonLayout();
        }
    }

    private void loadImageResources() {
        rightSightImage = loadImageWithFallback("img/bg/right_sight.png",
                ORIGINAL_RIGHT_PANEL_WIDTH, ORIGINAL_TOTAL_HEIGHT, Color.CYAN);
        bottomImage = loadImageWithFallback("img/bg/bottom.png",
                ORIGINAL_GAME_WIDTH, ORIGINAL_BOTTOM_PANEL_HEIGHT, Color.ORANGE);
        gameOverImage = loadImageWithFallback("img/bg/gameovers.png",
                ORIGINAL_TOTAL_WIDTH, ORIGINAL_TOTAL_HEIGHT, Color.DARK_GRAY);
    }

    private BufferedImage loadImageWithFallback(String path, int width, int height, Color fallbackColor) {
        try {
            File imageFile = new File(path);
            if (imageFile.exists()) {
                return ImageIO.read(imageFile);
            }
        } catch (IOException ignored) {
            // 静默处理，返回占位图片
        }
        return createPlaceholderImage(width, height, fallbackColor);
    }

    private BufferedImage createPlaceholderImage(int width, int height, Color color) {
        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        Graphics2D g2d = image.createGraphics();
        try {
            g2d.setColor(color);
            g2d.fillRect(0, 0, width, height);
            g2d.setColor(Color.BLACK);
            g2d.drawRect(0, 0, width - 1, height - 1);
            g2d.setColor(Color.WHITE);
            g2d.drawString("占位图片", width / 2 - 20, height / 2);
        } finally {
            g2d.dispose();
        }
        return image;
    }

    private void createRestartButton() {
        restartButton = new JButton(" ");
        configureRestartButton();
        add(restartButton);
        restartButton.setVisible(false);
        updateRestartButtonLayout();
    }

    private void configureRestartButton() {
        restartButton.setIcon(new ImageIcon("img/bg/gameover.jpg"));
        restartButton.setContentAreaFilled(false);
        restartButton.setBorderPainted(false);
        restartButton.setFocusPainted(false);
        restartButton.setHorizontalTextPosition(JButton.CENTER);
        restartButton.setVerticalTextPosition(JButton.CENTER);
        restartButton.setForeground(Color.WHITE);
        restartButton.setFont(new Font("宋体", Font.BOLD, 16));
        restartButton.addActionListener(e -> restartGame());
    }

    private void updateRestartButtonLayout() {
        int panelWidth = getWidth();
        int panelHeight = getHeight();

        if (panelWidth <= 0 || panelHeight <= 0) return;

        // 计算按钮尺寸和位置
        int buttonWidth = Math.max(200, panelWidth / 4);
        int buttonHeight = Math.max(60, panelHeight / 10);
        int buttonX = (panelWidth - buttonWidth) / 2;
        int buttonY = (int) (panelHeight * 0.8);

        restartButton.setBounds(buttonX, buttonY, buttonWidth, buttonHeight);

        // 更新按钮图标和字体
        updateRestartButtonIcon(buttonWidth, buttonHeight);
        updateRestartButtonFont(panelWidth, panelHeight);
    }

    private void updateRestartButtonIcon(int buttonWidth, int buttonHeight) {
        try {
            ImageIcon originalIcon = new ImageIcon("img/bg/gameover.jpg");
            Image scaledImage = originalIcon.getImage().getScaledInstance(
                    buttonWidth, buttonHeight, Image.SCALE_SMOOTH);
            restartButton.setIcon(new ImageIcon(scaledImage));
        } catch (Exception ignored) {
            // 忽略图标更新失败
        }
    }

    private void updateRestartButtonFont(int panelWidth, int panelHeight) {
        int fontSize = Math.max(14, Math.min(panelWidth, panelHeight) / 35);
        restartButton.setFont(new Font("宋体", Font.BOLD, fontSize));
    }

    private void updateCountdown() {
        if (gameOver || timeUp) return;

        long currentTime = System.currentTimeMillis();
        long elapsedTime = currentTime - gameStartTime;
        remainingTime = Math.max(0, GAME_DURATION_MS - elapsedTime);

        if (remainingTime == 0) {
            timeUp = true;
            gameOver = true;
        }
    }

    private String formatTime(long timeInMs) {
        long totalSeconds = timeInMs / 1000;
        long minutes = totalSeconds / 60;
        long seconds = totalSeconds % 60;
        return String.format("%02d:%02d", minutes, seconds);
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);

        Graphics2D g2d = (Graphics2D) g.create();
        try {
            setupGraphicsQuality(g2d);
            updateCountdown();

            double scaleX = (double) getWidth() / ORIGINAL_TOTAL_WIDTH;
            double scaleY = (double) getHeight() / ORIGINAL_TOTAL_HEIGHT;

            if (!gameOver) {
                renderGameContent(g2d, scaleX, scaleY);
            }

            renderUIComponents(g2d, scaleX, scaleY);
            checkGameEndConditions(g2d, scaleX, scaleY);

        } finally {
            g2d.dispose();
        }
    }

    private void setupGraphicsQuality(Graphics2D g2d) {
        g2d.setRenderingHints(RENDERING_HINTS);
    }

    private void renderGameContent(Graphics2D g2d, double scaleX, double scaleY) {
        int gameAreaWidth = (int) (ORIGINAL_GAME_WIDTH * scaleX);
        int gameAreaHeight = (int) (ORIGINAL_GAME_HEIGHT * scaleY);

        // 绘制游戏区域背景
        g2d.setColor(Color.WHITE);
        g2d.fillRect(0, 0, gameAreaWidth, gameAreaHeight);

        AffineTransform originalTransform = g2d.getTransform();
        try {
            g2d.setClip(0, 0, gameAreaWidth, gameAreaHeight);
            g2d.scale(scaleX, scaleY);

            renderGameElements(g2d);

        } finally {
            g2d.setTransform(originalTransform);
            g2d.setClip(null);
        }
    }

    private void renderGameElements(Graphics2D g2d) {
        Map<String, List<SuperElement>> elementMap = manager.getMap();
        List<String> sortedKeys = new ArrayList<>(elementMap.keySet());
        Collections.sort(sortedKeys);

        for (String key : sortedKeys) {
            List<SuperElement> elements = elementMap.get(key);
            for (SuperElement element : elements) {
                element.showElement(g2d);
            }
        }
    }

    private void renderUIComponents(Graphics2D g2d, double scaleX, double scaleY) {
        renderUIPanels(g2d, scaleX, scaleY);
        renderCountdown(g2d, scaleX, scaleY);
        renderPlayerScores(g2d, scaleX, scaleY);
    }

    private void renderUIPanels(Graphics2D g2d, double scaleX, double scaleY) {
        int gameAreaWidth = (int) (ORIGINAL_GAME_WIDTH * scaleX);
        int gameAreaHeight = (int) (ORIGINAL_GAME_HEIGHT * scaleY);
        int rightPanelWidth = (int) (ORIGINAL_RIGHT_PANEL_WIDTH * scaleX);
        int bottomPanelHeight = (int) (ORIGINAL_BOTTOM_PANEL_HEIGHT * scaleY);
        int totalHeight = (int) (ORIGINAL_TOTAL_HEIGHT * scaleY);

        // 右侧面板
        if (rightSightImage != null) {
            g2d.drawImage(rightSightImage, gameAreaWidth, 0, rightPanelWidth, totalHeight, this);
        } else {
            g2d.setColor(Color.CYAN);
            g2d.fillRect(gameAreaWidth, 0, rightPanelWidth, totalHeight);
        }

        // 底部面板
        if (bottomImage != null) {
            g2d.drawImage(bottomImage, 0, gameAreaHeight, gameAreaWidth, bottomPanelHeight, this);
        } else {
            g2d.setColor(Color.ORANGE);
            g2d.fillRect(0, gameAreaHeight, gameAreaWidth, bottomPanelHeight);
        }
    }

    private void renderCountdown(Graphics2D g2d, double scaleX, double scaleY) {
        int fontSize = Math.max(14, (int) (20 * Math.min(scaleX, scaleY)));
        g2d.setFont(new Font("宋体", Font.BOLD, fontSize));

        // 根据剩余时间设置颜色
        if (remainingTime > 30_000) {
            g2d.setColor(Color.GREEN);
        } else if (remainingTime > 10_000) {
            g2d.setColor(Color.YELLOW);
        } else {
            g2d.setColor(Color.RED);
        }

        int rightPanelX = (int) (ORIGINAL_GAME_WIDTH * scaleX) + 100;
        int countdownY = (int) (30 * scaleY)-5;

        g2d.drawString(formatTime(remainingTime), rightPanelX, countdownY);
    }

    private void renderPlayerScores(Graphics2D g2d, double scaleX, double scaleY) {
        List<SuperElement> playerList = manager.getElementList("play");
        if (playerList == null || playerList.size() < 2) return;

        int fontSize = Math.max(12, (int) (18 * Math.min(scaleX, scaleY)));
        g2d.setFont(new Font("宋体", Font.BOLD, fontSize));
        g2d.setColor(Color.BLACK);

        int rightPanelX = (int) (ORIGINAL_GAME_WIDTH * scaleX) + 100;
        int player1Y = (int) (60 * scaleY)+5;
        int player2Y = (int) (85 * scaleY)+30;

        // 绘制P1分数
        Player player1 = (Player) playerList.get(0);
        if (player1 != null) {
            g2d.drawString("P1: " + player1.getNum(), rightPanelX, player1Y);
        }

        // 绘制P2分数
        Player player2 = (Player) playerList.get(1);
        if (player2 != null) {
            g2d.drawString("P2: " + player2.getNum(), rightPanelX, player2Y);
        }
    }

    private void checkGameEndConditions(Graphics2D g2d, double scaleX, double scaleY) {
        if (!gameOver) {
            List<SuperElement> playerList = manager.getElementList("play");
            if (playerList != null && playerList.size() >= 2) {
                Player player1 = (Player) playerList.get(0);
                Player player2 = (Player) playerList.get(1);

                if ((player1 != null && player1.getNum() >= 1000) ||
                        (player2 != null && player2.getNum() >= 1000) ||
                        timeUp) {
                    gameOver = true;
                    updateRestartButtonLayout();
                }
            }
        }

        if (gameOver) {
            renderGameOverScreen(g2d, scaleX, scaleY);
        }
    }

    private void renderGameOverScreen(Graphics2D g2d, double scaleX, double scaleY) {
        // 绘制游戏结束背景
        if (gameOverImage != null) {
            g2d.drawImage(gameOverImage, 0, 0, getWidth(), getHeight(), this);
        } else {
            g2d.setColor(Color.DARK_GRAY);
            g2d.fillRect(0, 0, getWidth(), getHeight());
        }

        // 绘制胜利文本
        String winnerText = determineWinner();
        int fontSize = Math.max(24, (int) (36 * Math.min(scaleX, scaleY)));
        g2d.setFont(new Font("宋体", Font.BOLD, fontSize));

        FontMetrics fm = g2d.getFontMetrics();
        int textWidth = fm.stringWidth(winnerText);
        int textX = (getWidth() - textWidth) / 2;
        int textY = (int) (getHeight() * 0.6);

        // 文字阴影效果
        g2d.setColor(Color.BLACK);
        g2d.drawString(winnerText, textX + 2, textY + 2);
        g2d.setColor(Color.YELLOW);
        g2d.drawString(winnerText, textX, textY);

        // 显示重新开始按钮
        if (!restartButton.isVisible()) {
            restartButton.setVisible(true);
            setComponentZOrder(restartButton, 0);
        }
    }

    private String determineWinner() {
        List<SuperElement> playerList = manager.getElementList("play");
        if (playerList == null || playerList.size() < 2) return "游戏结束";

        Player player1 = (Player) playerList.get(0);
        Player player2 = (Player) playerList.get(1);

        if (player1 == null || player2 == null) return "游戏结束";

        if (timeUp) {
            int p1Score = player1.getNum();
            int p2Score = player2.getNum();

            if (p1Score > p2Score) {
                return String.format("时间到! 1P 胜利! (分数: %d)", p1Score);
            } else if (p2Score > p1Score) {
                return String.format("时间到! 2P 胜利! (分数: %d)", p2Score);
            } else {
                return String.format("时间到! 平局! (分数: %d)", p1Score);
            }
        } else if (player1.getNum() >= 1000) {
            return "1P 胜利! (率先达到1000分)";
        } else if (player2.getNum() >= 1000) {
            return "2P 胜利! (率先达到1000分)";
        }

        return "游戏结束";
    }

    private void restartGame() {
        resetGameState();
        restartButton.setVisible(false);
        running = false;

        MyGameJFrame myGameJFrame = (MyGameJFrame) SwingUtilities.getWindowAncestor(this);
        SwingUtilities.invokeLater(() -> {
            if (myGameJFrame != null) {
                myGameJFrame.dispose();
            }
            try {
                GameWindow gameWindow = new GameWindow();
                gameWindow.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
                resetCurrentGame();
            }
        });
    }

    private void resetGameState() {
        gameOver = false;
        timeUp = false;
        remainingTime = GAME_DURATION_MS;
        gameStartTime = System.currentTimeMillis();
    }

    private void resetCurrentGame() {
        resetGameState();
        restartButton.setVisible(false);
        running = true;
        repaint();
    }

    @Override
    public void run() {
        while (running) {
            try {
                TimeUnit.MILLISECONDS.sleep(16); // 60 FPS
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                break;
            }

            if (running) {
                SwingUtilities.invokeLater(this::repaint);
            }
        }
    }
}