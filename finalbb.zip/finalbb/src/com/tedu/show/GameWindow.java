package com.tedu.show;

import com.tedu.controller.GameListener;
import com.tedu.manager.ScaleManager;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;

public class GameWindow extends JFrame implements ActionListener {
    // 游戏配置常量
    public static int globalVariable = 10;
    private static final int TRANSITION_DURATION_MS = 6000;
    private static final String FONT_NAME = "宋体";

    // 布局比例常量
    private static final double MAP_SELECTOR_Y_RATIO = 0.65;
    private static final double START_BUTTON_Y_RATIO = 0.75;

    // 组件尺寸常量
    private static final int MAP_SELECTOR_WIDTH = 150;
    private static final int MAP_SELECTOR_HEIGHT = 30;
    private static final int START_BUTTON_WIDTH = 270;
    private static final int START_BUTTON_HEIGHT = 80;

    // 地图选项
    private static final String[] MAP_OPTIONS = {"地图 A", "地图 B"};
    private static final String MAP_A = "地图 A";
    private static final String MAP_B = "地图 B";

    // 图片路径常量
    private static final String START_GAME_ICON_PATH = "img/bg/startgame.png";
    private static final String BACKGROUND_IMAGE_PATH = "img/bg/start.png";

    // 渲染提示
    private static final RenderingHints RENDERING_HINTS = new RenderingHints(
            RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR
    );

    static {
        RENDERING_HINTS.put(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        RENDERING_HINTS.put(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
    }

    // UI组件
    private JPanel contentPane;
    private JComboBox<String> mapSelector;
    private JButton startButton;
    private JLabel backgroundLabel;

    // 管理器
    private final ScaleManager scaleManager;

    public GameWindow() {
        scaleManager = ScaleManager.getInstance();
        initializeFrame();
        setupComponents();
        setupEventListeners();
    }

    private void initializeFrame() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setTitle("泡泡堂");
        setSize(ScaleManager.BASE_WIDTH, ScaleManager.BASE_HEIGHT);
        setLocationRelativeTo(null);
        setResizable(true);

        // 创建内容面板
        contentPane = createContentPane();
        setContentPane(contentPane);

        // 移除窗口装饰
        getRootPane().setWindowDecorationStyle(JRootPane.NONE);
    }

    private JPanel createContentPane() {
        return new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g.create();
                try {
                    g2d.setRenderingHints(RENDERING_HINTS);
                } finally {
                    g2d.dispose();
                }
            }
        };
    }

    private void setupComponents() {
        contentPane.setLayout(null);

        createMapSelector();
        createStartButton();
        createBackgroundLabel();

        // 初始化组件尺寸
        updateComponentSizes();
    }

    private void setupEventListeners() {
        startButton.addActionListener(this);

        addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                onFrameResize();
            }
        });
    }

    private void createMapSelector() {
        mapSelector = new JComboBox<>(MAP_OPTIONS);

        // 设置初始位置和样式
        int centerX = ScaleManager.BASE_WIDTH / 2;
        int selectorY = (int) (ScaleManager.BASE_HEIGHT * MAP_SELECTOR_Y_RATIO);

        mapSelector.setBounds(
                centerX - scaleManager.scaleWidth(MAP_SELECTOR_WIDTH / 2),
                selectorY,
                scaleManager.scaleWidth(MAP_SELECTOR_WIDTH),
                scaleManager.scaleHeight(MAP_SELECTOR_HEIGHT)
        );

        mapSelector.setFont(new Font(FONT_NAME, Font.PLAIN, scaleManager.scaleFontSize(14)));
        contentPane.add(mapSelector);
    }

    private void createStartButton() {
        startButton = new JButton("开始游戏");

        // 设置按钮样式
        configureButtonStyle(startButton);

        // 设置初始位置
        int centerX = ScaleManager.BASE_WIDTH / 2;
        int buttonY = (int) (ScaleManager.BASE_HEIGHT * START_BUTTON_Y_RATIO);

        startButton.setBounds(
                centerX - scaleManager.scaleWidth(START_BUTTON_WIDTH / 2),
                buttonY,
                scaleManager.scaleWidth(START_BUTTON_WIDTH),
                scaleManager.scaleHeight(START_BUTTON_HEIGHT)
        );

        setButtonIcon(startButton, START_GAME_ICON_PATH,
                scaleManager.scaleWidth(START_BUTTON_WIDTH),
                scaleManager.scaleHeight(START_BUTTON_HEIGHT));

        contentPane.add(startButton);
    }

    private void configureButtonStyle(JButton button) {
        button.setContentAreaFilled(false);
        button.setBorderPainted(false);
        button.setFocusPainted(false);
    }

    private void createBackgroundLabel() {
        backgroundLabel = new JLabel();
        backgroundLabel.setBounds(0, 0, ScaleManager.BASE_WIDTH, ScaleManager.BASE_HEIGHT);

        setLabelIcon(backgroundLabel, BACKGROUND_IMAGE_PATH,
                ScaleManager.BASE_WIDTH, ScaleManager.BASE_HEIGHT);

        contentPane.add(backgroundLabel);
    }

    private void onFrameResize() {
        Dimension size = getSize();
        scaleManager.updateScale(size.width, size.height);
        updateComponentSizes();
        repaint();
    }

    private void updateComponentSizes() {
        updateMapSelectorSize();
        updateStartButtonSize();
        updateBackgroundLabelSize();
    }

    private void updateMapSelectorSize() {
        if (mapSelector == null) return;

        int centerX = scaleManager.getCurrentWidth() / 2;
        int selectorY = (int) (scaleManager.getCurrentHeight() * MAP_SELECTOR_Y_RATIO);

        mapSelector.setBounds(
                centerX - scaleManager.scaleWidth(MAP_SELECTOR_WIDTH / 2),
                selectorY,
                scaleManager.scaleWidth(MAP_SELECTOR_WIDTH),
                scaleManager.scaleHeight(MAP_SELECTOR_HEIGHT)
        );

        mapSelector.setFont(new Font(FONT_NAME, Font.PLAIN, scaleManager.scaleFontSize(14)));
    }

    private void updateStartButtonSize() {
        if (startButton == null) return;

        int centerX = scaleManager.getCurrentWidth() / 2;
        int buttonY = (int) (scaleManager.getCurrentHeight() * START_BUTTON_Y_RATIO);

        startButton.setBounds(
                centerX - scaleManager.scaleWidth(START_BUTTON_WIDTH / 2),
                buttonY,
                scaleManager.scaleWidth(START_BUTTON_WIDTH),
                scaleManager.scaleHeight(START_BUTTON_HEIGHT)
        );

        setButtonIcon(startButton, START_GAME_ICON_PATH,
                scaleManager.scaleWidth(START_BUTTON_WIDTH),
                scaleManager.scaleHeight(START_BUTTON_HEIGHT));
    }

    private void updateBackgroundLabelSize() {
        if (backgroundLabel == null) return;

        backgroundLabel.setBounds(0, 0,
                scaleManager.getCurrentWidth(),
                scaleManager.getCurrentHeight());

        setLabelIcon(backgroundLabel, BACKGROUND_IMAGE_PATH,
                scaleManager.getCurrentWidth(),
                scaleManager.getCurrentHeight());
    }

    private void setButtonIcon(JButton button, String imagePath, int width, int height) {
        try {
            ImageIcon originalIcon = new ImageIcon(imagePath);
            Image scaledImage = originalIcon.getImage().getScaledInstance(
                    width, height, Image.SCALE_SMOOTH);
            button.setIcon(new ImageIcon(scaledImage));
        } catch (Exception e) {
            // 静默处理图标加载失败
        }
    }

    private void setLabelIcon(JLabel label, String imagePath, int width, int height) {
        try {
            ImageIcon originalIcon = new ImageIcon(imagePath);
            Image scaledImage = originalIcon.getImage().getScaledInstance(
                    width, height, Image.SCALE_SMOOTH);
            label.setIcon(new ImageIcon(scaledImage));
        } catch (Exception e) {
            // 静默处理图标加载失败
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == startButton) {
            handleStartButtonClick();
        }
    }

    private void handleStartButtonClick() {
        String selectedMap = getSelectedMap();
        setGlobalVariableForMap(selectedMap);

        setVisible(false);
        showTransitionAndStartGame();
        dispose();
    }

    private String getSelectedMap() {
        return (String) mapSelector.getSelectedItem();
    }

    private void setGlobalVariableForMap(String selectedMap) {
        if (MAP_A.equals(selectedMap)) {
            globalVariable = 1;
        } else if (MAP_B.equals(selectedMap)) {
            globalVariable = 0;
        }
    }

    private void showTransitionAndStartGame() {
        TransitionFrame transitionFrame = new TransitionFrame();
        transitionFrame.setVisible(true);

        Timer transitionTimer = createTransitionTimer(transitionFrame);
        transitionTimer.start();
    }

    private Timer createTransitionTimer(TransitionFrame transitionFrame) {
        Timer timer = new Timer(TRANSITION_DURATION_MS, e -> {
            SwingUtilities.invokeLater(() -> {
                transitionFrame.dispose();
                startGameFrame();
            });
        });
        timer.setRepeats(false);
        return timer;
    }

    private void startGameFrame() {
        try {
            MyGameJFrame myGameJFrame = new MyGameJFrame();
            MyGameJPanel myGameJPanel = new MyGameJPanel();
            GameListener gameListener = new GameListener();

            setupGameFrame(myGameJFrame, myGameJPanel, gameListener);
            myGameJFrame.start();

        } catch (Exception e) {
            e.printStackTrace();
            // 可以在这里添加错误处理逻辑，比如显示错误对话框
            showErrorDialog("启动游戏失败，请重试");
        }
    }

    private void setupGameFrame(MyGameJFrame myGameJFrame, MyGameJPanel myGameJPanel, GameListener gameListener) {
        myGameJFrame.setKeyListener(gameListener);
        myGameJFrame.addListener();
        myGameJFrame.setJPanel(myGameJPanel);
        myGameJFrame.addJPanel();
    }

    private void showErrorDialog(String message) {
        JOptionPane.showMessageDialog(this, message, "错误", JOptionPane.ERROR_MESSAGE);
    }
}