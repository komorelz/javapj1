package com.tedu.show;

import com.tedu.controller.GameThread;
import com.tedu.manager.ScaleManager;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.List;

/**
 * 游戏主窗口类
 * 负责游戏窗口的创建、管理和事件处理
 */
public class MyGameJFrame extends JFrame {
    private static final String GAME_TITLE = "泡泡堂";
    private static final int DEFAULT_CLOSE_OPERATION = JFrame.EXIT_ON_CLOSE;

    private final ScaleManager scaleManager;
    private final List<KeyListener> keyListeners = new ArrayList<>();
    private final List<MouseListener> mouseListeners = new ArrayList<>();
    private final List<MouseMotionListener> mouseMotionListeners = new ArrayList<>();

    private JPanel gamePanel;
    private GameThread gameThread;
    private boolean isInitialized = false;

    public MyGameJFrame() {
        super(GAME_TITLE);
        this.scaleManager = ScaleManager.getInstance();
        init();
    }

    /**
     * 初始化窗口
     */
    private void init() {
        if (isInitialized) {
            return;
        }

        setupWindow();
        setupResizeListener();

        isInitialized = true;
    }

    /**
     * 设置窗口基本属性
     */
    private void setupWindow() {
        setSize(scaleManager.getCurrentWidth(), scaleManager.getCurrentHeight());
        setResizable(true);
        setDefaultCloseOperation(DEFAULT_CLOSE_OPERATION);
        setLocationRelativeTo(null);

        // 设置窗口图标（如果有的话）
        // setIconImage(loadIcon());
    }

    /**
     * 设置窗口大小改变监听器
     */
    private void setupResizeListener() {
        addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                handleResize();
            }
        });
    }

    /**
     * 处理窗口大小改变
     */
    private void handleResize() {
        Dimension size = getSize();
        scaleManager.updateScale(size.width, size.height);

        if (gamePanel != null) {
            gamePanel.setSize(size);
            gamePanel.revalidate();
            gamePanel.repaint();
        }
    }

    /**
     * 设置键盘监听器（兼容原有方法）
     */
    public void setKeyListener(KeyListener listener) {
        addKeyListenerInternal(listener);
    }

    /**
     * 设置鼠标监听器（兼容原有方法）
     */
    public void setMouseListener(MouseListener listener) {
        addMouseListenerInternal(listener);
    }

    /**
     * 设置鼠标移动监听器（兼容原有方法）
     */
    public void setMouseMotionListener(MouseMotionListener listener) {
        addMouseMotionListenerInternal(listener);
    }

    /**
     * 添加键盘监听器
     */
    public void addKeyListener(KeyListener listener) {
        addKeyListenerInternal(listener);
    }

    /**
     * 添加鼠标监听器
     */
    public void addMouseListener(MouseListener listener) {
        addMouseListenerInternal(listener);
    }

    /**
     * 添加鼠标移动监听器
     */
    public void addMouseMotionListener(MouseMotionListener listener) {
        addMouseMotionListenerInternal(listener);
    }

    /**
     * 内部方法：添加键盘监听器
     */
    private void addKeyListenerInternal(KeyListener listener) {
        if (listener != null && !keyListeners.contains(listener)) {
            keyListeners.add(listener);
            super.addKeyListener(listener);
        }
    }

    /**
     * 内部方法：添加鼠标监听器
     */
    private void addMouseListenerInternal(MouseListener listener) {
        if (listener != null && !mouseListeners.contains(listener)) {
            mouseListeners.add(listener);
            super.addMouseListener(listener);
        }
    }

    /**
     * 内部方法：添加鼠标移动监听器
     */
    private void addMouseMotionListenerInternal(MouseMotionListener listener) {
        if (listener != null && !mouseMotionListeners.contains(listener)) {
            mouseMotionListeners.add(listener);
            super.addMouseMotionListener(listener);
        }
    }

    /**
     * 移除键盘监听器
     */
    public void removeKeyListener(KeyListener listener) {
        if (listener != null) {
            keyListeners.remove(listener);
            super.removeKeyListener(listener);
        }
    }

    /**
     * 移除鼠标监听器
     */
    public void removeMouseListener(MouseListener listener) {
        if (listener != null) {
            mouseListeners.remove(listener);
            super.removeMouseListener(listener);
        }
    }

    /**
     * 移除鼠标移动监听器
     */
    public void removeMouseMotionListener(MouseMotionListener listener) {
        if (listener != null) {
            mouseMotionListeners.remove(listener);
            super.removeMouseMotionListener(listener);
        }
    }

    /**
     * 设置游戏面板（兼容原有方法）
     */
    public void setJPanel(JPanel panel) {
        setGamePanel(panel);
    }

    /**
     * 设置游戏面板
     */
    public void setGamePanel(JPanel panel) {
        if (gamePanel != null) {
            remove(gamePanel);
        }

        this.gamePanel = panel;

        if (gamePanel != null) {
            add(gamePanel, BorderLayout.CENTER);
            revalidate();
            repaint();
        }
    }

    /**
     * 绑定所有监听器（兼容原有方法）
     */
    public void addListener() {
        // 这个方法在新版本中不需要额外操作
        // 因为监听器在设置时就已经自动添加了
    }

    /**
     * 绑定游戏面板（兼容原有方法）
     */
    public void addJPanel() {
        // 这个方法在新版本中不需要额外操作
        // 因为面板在设置时就已经自动添加了
    }

    /**
     * 获取游戏面板
     */
    public JPanel getGamePanel() {
        return gamePanel;
    }

    /**
     * 启动游戏
     */
    public void start() {
        if (!isInitialized) {
            throw new IllegalStateException("游戏窗口尚未初始化");
        }

        // 显示窗口
        setVisible(true);

        // 启动游戏面板线程（如果游戏面板实现了Runnable接口）
        startGamePanelThread();

        // 启动游戏主线程
        startGameThread();
    }

    /**
     * 启动游戏面板线程
     */
    private void startGamePanelThread() {
        if (gamePanel instanceof Runnable) {
            Thread panelThread = new Thread((Runnable) gamePanel);
            panelThread.setName("GamePanel-Thread");
            panelThread.setDaemon(true);
            panelThread.start();
        }
    }

    /**
     * 启动游戏主线程
     */
    private void startGameThread() {
        if (gameThread == null) {
            gameThread = new GameThread();
            gameThread.start();
        }
    }

    /**
     * 停止游戏
     */
    public void stop() {
        if (gameThread != null) {
            gameThread.interrupt();
            gameThread = null;
        }

        // 清理资源
        cleanup();
    }

    /**
     * 清理资源
     */
    private void cleanup() {
        keyListeners.clear();
        mouseListeners.clear();
        mouseMotionListeners.clear();

        if (gamePanel != null) {
            remove(gamePanel);
            gamePanel = null;
        }
    }

    /**
     * 获取缩放管理器
     */
    public ScaleManager getScaleManager() {
        return scaleManager;
    }

    /**
     * 检查游戏是否正在运行
     */
    public boolean isGameRunning() {
        return gameThread != null && gameThread.isAlive();
    }

    /**
     * 设置窗口标题
     */
    public void setGameTitle(String title) {
        if (title != null && !title.trim().isEmpty()) {
            setTitle(title);
        }
    }

    /**
     * 重写dispose方法，确保资源正确释放
     */
    @Override
    public void dispose() {
        stop();
        super.dispose();
    }
}