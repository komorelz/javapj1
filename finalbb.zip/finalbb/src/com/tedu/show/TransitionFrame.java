package com.tedu.show;

import com.tedu.manager.ScaleManager;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.util.Timer;
import java.util.TimerTask;

public class TransitionFrame extends JFrame {
    private JLabel label;
    private int counter = 0;
    private ScaleManager scaleManager;
    private Timer timer;
    private ImageIcon[] loadingImages;

    public TransitionFrame() {
        scaleManager = ScaleManager.getInstance();
        setTitle("过渡界面");
        setSize(scaleManager.getCurrentWidth(), scaleManager.getCurrentHeight());
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(true);

        // 预加载图片
        loadingImages = new ImageIcon[2];
        loadingImages[0] = new ImageIcon("img/loading1.png");
        loadingImages[1] = new ImageIcon("img/loading2.png");

        label = new JLabel() {
            @Override
            protected void paintComponent(Graphics g) {
                if (loadingImages[counter % 2] != null) {
                    Graphics2D g2d = (Graphics2D) g.create();
                    g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
                    g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
                    g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                    // 直接绘制图片，填满整个组件
                    Image img = loadingImages[counter % 2].getImage();
                    g2d.drawImage(img, 0, 0, getWidth(), getHeight(), this);

                    // 在右下角绘制加载文本
                    drawLoadingText(g2d);

                    g2d.dispose();
                } else {
                    super.paintComponent(g);
                    // 即使没有图片也要显示加载文本
                    Graphics2D g2d = (Graphics2D) g.create();
                    g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                    drawLoadingText(g2d);
                    g2d.dispose();
                }
            }

            private void drawLoadingText(Graphics2D g2d) {
                // 设置字体和颜色
                Font font = new Font("微软雅黑", Font.BOLD, 25);
                g2d.setFont(font);
                g2d.setColor(Color.black);

                String loadingText = "正在加载中…………";
                FontMetrics fm = g2d.getFontMetrics();
                int textWidth = fm.stringWidth(loadingText);
                int textHeight = fm.getHeight();

                // 计算右下角位置（留出一些边距）
                int x = getWidth() - textWidth - 40;
                int y = getHeight() - 33;

                // 绘制文本阴影效果
                g2d.setColor(Color.BLACK);
                g2d.drawString(loadingText, x + 1, y + 1);

                // 绘制主文本
                g2d.setColor(Color.white);
                g2d.drawString(loadingText, x, y);
            }
        };
        label.setHorizontalAlignment(SwingConstants.CENTER);
        label.setVerticalAlignment(SwingConstants.CENTER);
        add(label);

        // 添加组件调整监听器
        addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                onResize();
            }
        });

        // 启动定时器，定期切换图片
        startImageSwitching();

        // 初始化图片 - 延迟执行确保组件已经渲染
        SwingUtilities.invokeLater(() -> updateImage());
    }

    private void onResize() {
        Dimension size = getSize();
        scaleManager.updateScale(size.width, size.height);
        updateImage();
    }

    private void updateImage() {
        // 使用自定义绘制时，只需要触发重绘
        label.repaint();
    }

    // 启动定时器，定时切换图片
    private void startImageSwitching() {
        timer = new Timer();

        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                SwingUtilities.invokeLater(() -> {
                    counter++;
                    updateImage();
                });
            }
        }, 0, 3000);
    }

    @Override
    public void dispose() {
        if (timer != null) {
            timer.cancel();
            timer = null;
        }
        super.dispose();
    }
}