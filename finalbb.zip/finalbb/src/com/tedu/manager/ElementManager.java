package com.tedu.manager;

import com.tedu.element.*;

import java.util.*;

public class ElementManager {
	// 常量定义
	private static final int GRID_SIZE = 12;
	private static final int CELL_SIZE = 40;
	private static final int MAX_COORDINATE = 440;
	private static final int DEBUG_INTERVAL = 10;

	// 游戏元素类型常量
	private static final int BOMB_TYPE = 4;
	private static final int BOOM_BOX_TYPE = 3;

	// 游戏元素分类键名
	private static final String[] ELEMENT_KEYS = {
			"play", "bubble", "enemylist", "playfire",
			"box", "prop", "background", "bomb"
	};

	// 核心数据结构
	private final Map<String, List<SuperElement>> elementMap;
	private final SuperElement[][] gameGrid;

	// 单例实例
	private static volatile ElementManager instance;

	private ElementManager() {
		this.elementMap = initializeElementMap();
		this.gameGrid = new SuperElement[GRID_SIZE][GRID_SIZE];
	}

	/**
	 * 线程安全的单例获取方法
	 */
	public static ElementManager getInstance() {
		if (instance == null) {
			synchronized (ElementManager.class) {
				if (instance == null) {
					instance = new ElementManager();
				}
			}
		}
		return instance;
	}

	/**
	 * 初始化元素映射表
	 */
	private Map<String, List<SuperElement>> initializeElementMap() {
		Map<String, List<SuperElement>> map = new HashMap<>();
		for (String key : ELEMENT_KEYS) {
			map.put(key, new ArrayList<>());
		}
		return map;
	}

	// Getter方法
	public Map<String, List<SuperElement>> getMap() {
		return elementMap;
	}

	public Map<String, List<SuperElement>> getElementMap() {
		return Collections.unmodifiableMap(elementMap);
	}

	public List<SuperElement> getElementList(String key) {
		return elementMap.getOrDefault(key, new ArrayList<>());
	}

	/**
	 * 根据像素坐标设置网格元素
	 */
	public void setElementByPx(int row, int col, SuperElement element) {
		if (isValidPosition(row, col)) {
			gameGrid[row / CELL_SIZE][col / CELL_SIZE] = element;
		}
	}

	/**
	 * 根据像素坐标获取网格元素
	 */
	public SuperElement getElementByPx(int row, int col) {
		if (!isValidPosition(row, col)) {
			return null;
		}
		return gameGrid[row / CELL_SIZE][col / CELL_SIZE];
	}

	/**
	 * 根据像素坐标移除网格元素
	 */
	public SuperElement removeElementByPx(int row, int col) {
		SuperElement element = getElementByPx(row, col);
		if (element != null) {
			setElementByPx(row, col, null);
		}
		return element;
	}

	// 新的方法名（推荐使用）
	public void setElementByPosition(int row, int col, SuperElement element) {
		setElementByPx(row, col, element);
	}

	public SuperElement getElementByPosition(int row, int col) {
		return getElementByPx(row, col);
	}

	public SuperElement removeElementByPosition(int row, int col) {
		return removeElementByPx(row, col);
	}

	/**
	 * 检查坐标是否有效
	 */
	private boolean isValidPosition(int row, int col) {
		return row >= 0 && row <= MAX_COORDINATE && col >= 0 && col <= MAX_COORDINATE;
	}

	/**
	 * 加载游戏元素
	 */
	public void load() {
		loadGameElements();
	}

	/**
	 * 游戏主循环逻辑
	 */
	public void linkGame(int time) {
		updateGame(time);
	}

	/**
	 * 检查指定位置是否可以放置炸弹
	 */
	public boolean isBomb(int row, int col) {
		return canPlaceBomb(row, col);
	}

	// 新的优化方法实现
	public void loadGameElements() {
		// 初始化工厂加载器
		ElementFactory.ElementLoad loader = ElementFactory.ElementLoad.getInstance();
		loadConfigurations(loader);

		// 加载背景
		loadBackground();

		// 加载玩家
		loadPlayers();

		// 加载箱子
		loadBoxes(loader);
	}

	/**
	 * 加载配置文件
	 */
	private void loadConfigurations(ElementFactory.ElementLoad loader) {
		loader.readImagePro();
		loader.readPlayerPro();
		loader.readGamePro();
		loader.readBoxPro();
	}

	/**
	 * 加载背景元素
	 */
	private void loadBackground() {
		SceneContext background = SceneContext.createBackground();
		elementMap.get("background").add(background);
	}

	/**
	 * 加载玩家元素
	 */
	private void loadPlayers() {
		List<SuperElement> players = elementMap.get("play");

		Player player1 = (Player) ElementFactory.elementFactory("onePlayer");
		Player player2 = (Player) ElementFactory.elementFactory("twoPlayer");

		players.add(player1);
		players.add(player2);
	}

	/**
	 * 加载箱子元素
	 */
	private void loadBoxes(ElementFactory.ElementLoad loader) {
		List<SuperElement> boxes = elementMap.get("box");
		Map<String, List<String>> boxMap = loader.getBoxMap();

		for (List<String> boxData : boxMap.values()) {
			if (!boxData.isEmpty()) {
				String boxInfo = boxData.get(0);
				Box box = createBox(boxInfo);

				boxes.add(box);
				setElementByPx(box.getY(), box.getX(), box);
			}
		}
	}

	/**
	 * 创建箱子对象
	 */
	private Box createBox(String boxInfo) {
		String[] attributes = boxInfo.split(",");
		String boxType = attributes[0];

		return "boombox".equals(boxType) ?
				BoomBox.createBox(boxInfo) :
				UnBoomBox.createBox(boxInfo);
	}

	/**
	 * 游戏主循环逻辑实现
	 */
	public void updateGame(int timeStep) {
		List<SuperElement> players = elementMap.get("play");

		if (players.size() < 2) {
			return;
		}

		Player player1 = (Player) players.get(0);
		Player player2 = (Player) players.get(1);

		// 调试信息输出
		if (timeStep % DEBUG_INTERVAL == 0) {
			printPlayerStatus(player1, player2);
		}
	}

	/**
	 * 打印玩家状态
	 */
	private void printPlayerStatus(Player player1, Player player2) {

	}

	/**
	 * 检查指定位置是否可以放置炸弹实现
	 */
	public boolean canPlaceBomb(int row, int col) {
		SuperElement element = getElementByPx(row, col);
		return element == null || element.getObjectType() != BOMB_TYPE;
	}

	/**
	 * 检查指定位置是否为可爆炸箱子
	 */
	public boolean isBoomBox(int row, int col) {
		SuperElement element = getElementByPx(row, col);
		return element != null && element.getObjectType() == BOOM_BOX_TYPE;
	}
}