package com.tedu.manager;

import java.awt.*;

public class ScaleManager {
    // 基础分辨率
    public static final int BASE_WIDTH = 960;
    public static final int BASE_HEIGHT = 720;

    // 当前窗口分辨率
    private static int currentWidth = BASE_WIDTH;
    private static int currentHeight = BASE_HEIGHT;

    // 缩放比例
    private static double scaleX = 1.0;
    private static double scaleY = 1.0;

    // 单例实例
    private static ScaleManager instance;

    private ScaleManager() {}

    public static ScaleManager getInstance() {
        if (instance == null) {
            instance = new ScaleManager();
        }
        return instance;
    }

    // 更新当前分辨率和缩放比例
    public void updateScale(int width, int height) {
        currentWidth = width;
        currentHeight = height;
        scaleX = (double) width / BASE_WIDTH;
        scaleY = (double) height / BASE_HEIGHT;
    }

    // 获取缩放后的宽度
    public int scaleWidth(int width) {
        return (int) (width * scaleX);
    }

    // 获取缩放后的高度
    public int scaleHeight(int height) {
        return (int) (height * scaleY);
    }

    // 获取缩放后的字体大小
    public int scaleFontSize(int fontSize) {
        return (int) (fontSize * Math.min(scaleX, scaleY));
    }


    public int getCurrentWidth() { return currentWidth; }
    public int getCurrentHeight() { return currentHeight; }
}