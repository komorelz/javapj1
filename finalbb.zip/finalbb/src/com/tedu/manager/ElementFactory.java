package com.tedu.manager;

import com.tedu.element.Player;
import com.tedu.element.SuperElement;

import javax.swing.*;
import java.io.IOException;
import java.io.InputStream;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

import static com.tedu.show.GameWindow.globalVariable;

/**
 * 元素工厂类
 * 负责根据参数创建不同类型的游戏元素
 * 封装了复杂的构造方式，提供统一的创建接口
 */
public class ElementFactory {

	private static final String PLAYER_ONE = "onePlayer";
	private static final String PLAYER_TWO = "twoPlayer";
	private static final String ENEMY = "enemy";

	/**
	 * 元素工厂方法
	 * 根据名称创建对应的游戏元素
	 *
	 * @param name 元素名称
	 * @return 创建的游戏元素，如果名称不匹配则返回null
	 */
	public static SuperElement elementFactory(String name) {
		if (name == null || name.trim().isEmpty()) {
			return null;
		}

		ElementLoad loader = ElementLoad.getInstance();

		switch (name) {
			case PLAYER_ONE:
				return createPlayer(loader.getPlayMap(), PLAYER_ONE);
			case PLAYER_TWO:
				return createPlayer(loader.getPlayMap(), PLAYER_TWO);
			case ENEMY:
				return createEnemy(loader.getGameList());
			default:
				System.err.println("未知的元素类型: " + name);
				return null;
		}
	}

	/**
	 * 创建玩家元素
	 */
	private static SuperElement createPlayer(Map<String, List<String>> playMap, String playerType) {
		List<String> playerList = playMap.get(playerType);
		if (playerList == null || playerList.isEmpty()) {
			System.err.println("无法找到玩家类型: " + playerType);
			return null;
		}

		String playerData = playerList.get(0);
		return Player.createPlayer(playerData);
	}

	/**
	 * 创建敌人元素
	 */
	private static SuperElement createEnemy(List<String> gameList) {
		if (gameList == null || gameList.isEmpty()) {
			System.err.println("游戏列表为空，无法创建敌人");
			return null;
		}

		String enemyData = gameList.get(gameList.size() - 1);
		// TODO: 实现敌人创建逻辑
		return null; // 占位符，若有 Enemy 类需更新
	}

	/**
	 * 元素加载器内部类
	 * 负责加载和管理游戏资源
	 */
	public static class ElementLoad {
		// 配置文件路径常量
		private static final String BOX_CONFIG_PATH = "com/tedu/text/box%d.pro";
		private static final String GAME_CONFIG_PATH = "com/tedu/text/GameRunA.pro";
		private static final String PLAYER_CONFIG_PATH = "com/tedu/text/play.pro";
		private static final String IMAGE_CONFIG_PATH_A = "com/tedu/text/mapA.pro";
		private static final String IMAGE_CONFIG_PATH_B = "com/tedu/text/mapB.pro";

		// 使用线程安全的 ConcurrentHashMap
		private final Map<String, ImageIcon> imageMap;
		private final Map<String, List<String>> playMap;
		private final Map<String, List<String>> enemyMap;
		private final Map<String, List<String>> boxMap;
		private final List<String> gameList;
		private final Properties properties;

		private static volatile ElementLoad load;

		private ElementLoad() {
			imageMap = new ConcurrentHashMap<>();
			playMap = new ConcurrentHashMap<>();
			enemyMap = new ConcurrentHashMap<>();
			boxMap = new ConcurrentHashMap<>();
			gameList = Collections.synchronizedList(new ArrayList<>());
			properties = new Properties();
		}

		/**
		 * 获取 ElementLoad 单例实例
		 * 使用双重检查锁定确保线程安全
		 */
		public static ElementLoad getInstance() {
			if (load == null) {
				synchronized (ElementLoad.class) {
					if (load == null) {
						load = new ElementLoad();
					}
				}
			}
			return load;
		}

		/**
		 * 读取箱子配置文件
		 */
		public void readBoxPro() {
			String configPath = String.format(BOX_CONFIG_PATH, globalVariable);

			try (InputStream inputStream = getResourceAsStream(configPath)) {
				if (inputStream == null) {
					System.err.println("无法加载箱子配置文件: " + configPath);
					return;
				}

				loadPropertiesAndProcess(inputStream, (key, value) -> {
					List<String> boxList = new ArrayList<>();
					boxList.add(value);
					boxMap.put(key, boxList);
				});

				System.out.println("已加载 boxMap，共 " + boxMap.size() + " 个箱子类型");
			} catch (IOException e) {
				System.err.println("读取箱子配置文件时发生错误: " + e.getMessage());
				e.printStackTrace();
			}
		}

		/**
		 * 读取游戏配置文件
		 */
		public void readGamePro() {
			try (InputStream inputStream = getResourceAsStream(GAME_CONFIG_PATH)) {
				if (inputStream == null) {
					System.err.println("无法加载游戏配置文件: " + GAME_CONFIG_PATH);
					return;
				}

				gameList.clear();
				loadPropertiesAndProcess(inputStream, (key, value) -> gameList.add(value));

				System.out.println("已加载 gameList，共 " + gameList.size() + " 个游戏配置");
			} catch (IOException e) {
				System.err.println("读取游戏配置文件时发生错误: " + e.getMessage());
				e.printStackTrace();
			}
		}

		/**
		 * 读取玩家配置文件
		 */
		public void readPlayerPro() {
			try (InputStream inputStream = getResourceAsStream(PLAYER_CONFIG_PATH)) {
				if (inputStream == null) {
					System.err.println("无法加载玩家配置文件: " + PLAYER_CONFIG_PATH);
					return;
				}

				loadPropertiesAndProcess(inputStream, (key, value) -> {
					List<String> playerList = new ArrayList<>();
					playerList.add(value);
					playMap.put(key, playerList);
				});

				System.out.println("已加载 playMap，共 " + playMap.size() + " 个玩家类型");
			} catch (IOException e) {
				System.err.println("读取玩家配置文件时发生错误: " + e.getMessage());
				e.printStackTrace();
			}
		}

		/**
		 * 读取图片配置文件
		 */
		public void readImagePro() {
			String configPath = (globalVariable == 1) ? IMAGE_CONFIG_PATH_A : IMAGE_CONFIG_PATH_B;

			try (InputStream inputStream = getResourceAsStream(configPath)) {
				if (inputStream == null) {
					System.err.println("无法加载图片配置文件: " + configPath);
					return;
				}

				loadPropertiesAndProcess(inputStream, (key, value) -> {
					try {
						ImageIcon imageIcon = new ImageIcon(value);
						// 验证图片是否成功加载
						if (imageIcon.getIconWidth() == -1 || imageIcon.getIconHeight() == -1) {

						} else {
							imageMap.put(key, imageIcon);
						}
					} catch (Exception e) {
						System.err.println("创建图片图标时发生错误: " + value + " - " + e.getMessage());
					}
				});

				System.out.println("已加载 imageMap，共 " + imageMap.size() + " 个图片资源");
			} catch (IOException e) {
				System.err.println("读取图片配置文件时发生错误: " + e.getMessage());
				e.printStackTrace();
			}
		}

		/**
		 * 获取资源输入流
		 */
		private InputStream getResourceAsStream(String path) {
			return ElementLoad.class.getClassLoader().getResourceAsStream(path);
		}

		/**
		 * 加载Properties文件并处理每个键值对
		 */
		private void loadPropertiesAndProcess(InputStream inputStream, PropertyProcessor processor)
				throws IOException {
			properties.clear();
			properties.load(inputStream);

			for (Object keyObj : properties.keySet()) {
				String key = keyObj.toString();
				String value = properties.getProperty(key);
				if (value != null && !value.trim().isEmpty()) {
					processor.process(key, value);
				}
			}
		}

		/**
		 * 属性处理器接口
		 */
		@FunctionalInterface
		private interface PropertyProcessor {
			void process(String key, String value);
		}

		/**
		 * 清理所有缓存的资源
		 */
		public void clearCache() {
			imageMap.clear();
			playMap.clear();
			enemyMap.clear();
			boxMap.clear();
			gameList.clear();
			properties.clear();
		}

		/**
		 * 获取资源统计信息
		 */
		public String getResourceStats() {
			return String.format("资源统计 - 图片: %d, 玩家: %d, 敌人: %d, 箱子: %d, 游戏配置: %d",
					imageMap.size(), playMap.size(), enemyMap.size(), boxMap.size(), gameList.size());
		}

		// Getter 方法保持不变
		public Map<String, ImageIcon> getImageMap() {
			return new HashMap<>(imageMap); // 返回副本以保证线程安全
		}

		public Map<String, List<String>> getPlayMap() {
			return new HashMap<>(playMap); // 返回副本以保证线程安全
		}

		public List<String> getGameList() {
			return new ArrayList<>(gameList); // 返回副本以保证线程安全
		}

		public Map<String, List<String>> getBoxMap() {
			return new HashMap<>(boxMap); // 返回副本以保证线程安全
		}

		public Map<String, List<String>> getEnemyMap() {
			return new HashMap<>(enemyMap); // 返回副本以保证线程安全
		}
	}
}