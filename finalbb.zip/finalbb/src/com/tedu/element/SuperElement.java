package com.tedu.element;

import java.awt.*;

/**
 * 所有游戏元素的父类，定义了游戏元素的基本属性和行为。
 */
public abstract class SuperElement {

	private int x, y;  // x , y 画图片的左上角 x, y
	private int w, h;  // 宽 , 高
	private boolean visible;  // 默认为 true 代表存活
	private int objectType;  // 物体类型：0 - 无，1 - 人，2 - 道具，3 - 爆炸箱子，4 - 不可爆炸箱子，5 - 泡泡

	public void update() {
		move();
		destroy();
	}

	public abstract void showElement(Graphics g);  // 显示元素
	public abstract void move();  // 移动元素
	public abstract void destroy();  // 销毁元素

	// 构造方法
	public SuperElement() {
		this.visible = true;
	}

	public SuperElement(int x, int y, int w, int h) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.visible = true;
		this.objectType = 0;  // 默认类型为 0
	}

	/**
	 * 碰撞检测，检查两个元素是否相交
	 */
	public boolean gamePK(SuperElement superElement) {
		Rectangle r1 = new Rectangle(x, y, w, h);
		Rectangle r2 = new Rectangle(superElement.x, superElement.y, superElement.w, superElement.h);
		return r1.intersects(r2);  // 如果矩形有交集，返回 true
	}

	// 显示坐标点（可以重写）
	public int getShowY() {
		return getY();
	}

	public int getShowX() {
		return getX();
	}

	// 标准坐标
	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

	public boolean isVisible() {
		return visible;
	}

	public void setVisible(boolean visible) {
		this.visible = visible;
	}

	public int getW() {
		return w;
	}

	public void setW(int w) {
		this.w = w;
	}

	public int getH() {
		return h;
	}

	public void setH(int h) {
		this.h = h;
	}

	public int getObjectType() {
		return objectType;
	}

	public void setObjectType(int objectType) {
		this.objectType = objectType;
	}

	// 允许通过
	public abstract boolean allowpass();
}
