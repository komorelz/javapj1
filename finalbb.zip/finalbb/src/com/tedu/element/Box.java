package com.tedu.element;

import com.tedu.manager.ElementManager;

import javax.swing.*;
import java.awt.*;

/**
 * 地图上的木箱或墙体——不可穿越、可被炸毁。
 */
public class Box extends SuperElement {

	/* ─── 常量 ─────────────────────────────────────────── */
	private static final int TILE = 40;   // 单格大小

	/* ─── 属性 ─────────────────────────────────────────── */
	private final int indexX;     // 格子坐标
	private final int indexY;
	private final ImageIcon icon; // 贴图

	/* ─── 构造 ─────────────────────────────────────────── */
	public Box(int indexX, int indexY, ImageIcon icon) {
		super(indexX * TILE, indexY * TILE, TILE, TILE);
		this.indexX = indexX;
		this.indexY = indexY;
		this.icon   = icon;
	}

	/** 简便工厂：传图片路径即可创建 */
	public static Box createBox(int indexX, int indexY, String imgPath) {
		return new Box(indexX, indexY, new ImageIcon(imgPath));
	}

	/* ─── 渲染 ─────────────────────────────────────────── */
	@Override
	public void showElement(Graphics g) {
		if (!isVisible()) return;
		g.drawImage(icon.getImage(), getX(), getY(), getW(), getH(), null);
	}

	/* ─── 逻辑帧更新 ───────────────────────────────────── */
	@Override
	public void move() {
		/* Box 固定不动 */
	}

	/** 被炸后应从网格与元素管理器中移除 */
	@Override
	public void destroy() {
		if (!isVisible()) {
			CellBlock.setGridByPx(getY(), getX(), 0);
			ElementManager.getInstance().removeElementByPx(getY(), getX());
		}
	}

	/* ─── 其他特性 ─────────────────────────────────────── */
	@Override
	public boolean allowpass() {
		return false;   // 玩家 / 爆炸不能穿
	}

	/* ─── Getter ──────────────────────────────────────── */
	public int getIndexX()        { return indexX; }
	public int getIndexY()        { return indexY; }
	public ImageIcon getImageIcon() { return icon; }
}

