package com.tedu.element;

import com.tedu.manager.ElementFactory;
import com.tedu.show.GameWindow;

import javax.swing.*;
import java.awt.*;

/**
 * 场景背景类，用于绘制背景图及管理相关逻辑。
 */
public class SceneContext extends SuperElement {

	/* ─── 常量 ─────────────────────────────────────────── */
	private static final int SCENE_WIDTH = 480;  // 场景宽度
	private static final int SCENE_HEIGHT = 480; // 场景高度
	private static final String BG_PREFIX = "bg";  // 背景文件前缀

	/* ─── 属性 ─────────────────────────────────────────── */
	private final ImageIcon icon;  // 背景图像
	private final int index;       // 背景索引

	/* ─── 构造 ─────────────────────────────────────────── */
	public SceneContext(int x, int y, int w, int h, ImageIcon icon, int index) {
		super(x, y, w, h);
		this.icon = icon;
		this.index = index;
	}

	/* ─── 渲染 ─────────────────────────────────────────── */
	@Override
	public void showElement(Graphics g) {
		if (icon != null) {
			g.drawImage(icon.getImage(), 0, 0, SCENE_WIDTH, SCENE_HEIGHT, null);
		} else {
			System.err.println("背景图未加载，无法渲染！");
		}
	}

	/* ─── 无移动 ───────────────────────────────────────── */
	@Override
	public void move() {
		// 无移动逻辑
	}

	/* ─── 无销毁 ───────────────────────────────────────── */
	@Override
	public void destroy() {
		// 无销毁逻辑
	}

	/* ─── 工厂方法 ─────────────────────────────────────── */
	public static SceneContext createBackground() {
		int bgIndex = (GameWindow.globalVariable == 1) ? 3 : 4; // 根据条件选择背景
		String bgKey = BG_PREFIX + bgIndex;

		ImageIcon icon = ElementFactory.ElementLoad.getInstance().getImageMap().get(bgKey);
		if (icon == null) {
			System.err.println("无法加载背景图片: " + bgKey);
			// 你可以在这里使用默认背景图，或选择其他处理方式
		}

		return new SceneContext(0, 0, SCENE_WIDTH, SCENE_HEIGHT, icon, bgIndex);
	}

	/* ─── 允许通行 ─────────────────────────────────────── */
	@Override
	public boolean allowpass() {
		return true;  // 背景是可通行的
	}
}
