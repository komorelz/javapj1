package com.tedu.element;

/**
 * 地图格点矩阵，负责记录场景中各单元的占用类型。
 */
public final class CellBlock {

	/* ─── 常量 ─────────────────────────────────────────── */
	public static final int TILE = 40;     // 单格像素尺寸
	public static final int GRID_SIZE = 12;

	/* ─── 格子类型 ─────────────────────────────────────── */
	public static final int EMPTY        = 0;
	public static final int PLAYER       = 1;
	public static final int PROP         = 2;
	public static final int BOOM_BOX     = 3;
	public static final int SOLID_BOX    = 4;
	public static final int BUBBLE       = 5;

	/* ─── 数据存储 ─────────────────────────────────────── */
	private static final int[][] grid = new int[GRID_SIZE][GRID_SIZE];
	// 如果需要并发安全，可改为:
	// private static final java.util.concurrent.atomic.AtomicIntegerArray[] grid = ...

	/* ─── 禁止实例化 ───────────────────────────────────── */
	private CellBlock() {}

	/* ─── 查询接口 ─────────────────────────────────────── */
	public static int getTypeByIndex(int row, int col) {
		return inside(row, col) ? grid[row][col] : EMPTY;
	}

	public static int getTypeByPx(int y, int x) {
		return getTypeByIndex(y / TILE, x / TILE);
	}

	/* ─── 写入接口 ─────────────────────────────────────── */
	public static void setGridByIndex(int row, int col, int type) {
		if (inside(row, col)) {
			grid[row][col] = type;
		}
	}

	public static void setGridByPx(int y, int x, int type) {
		setGridByIndex(y / TILE, x / TILE, type);
	}

	/* ─── 工具方法 ─────────────────────────────────────── */
	private static boolean inside(int row, int col) {
		return row >= 0 && row < GRID_SIZE && col >= 0 && col < GRID_SIZE;
	}
}
