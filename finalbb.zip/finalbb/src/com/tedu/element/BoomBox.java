package com.tedu.element;

import com.tedu.manager.ElementFactory;
import com.tedu.manager.ElementManager;

import javax.swing.*;
import java.awt.*;
import java.util.List;
import java.util.Random;

/**
 * 爆炸箱子类，继承自 Box，具备道具生成与销毁功能。
 */
public class BoomBox extends Box {

	/* ─── 常量 ─────────────────────────────────────────── */
	private static final int PROP_TYPE_COUNT = 9;  // 可生成的道具种类数
	private static final String PROP_LIST_KEY = "prop";  // 道具列表在 ElementManager 中的标识

	private Random random;  // 随机数生成器

	/* ─── 构造 ─────────────────────────────────────────── */
	public BoomBox(int indexX, int indexY, ImageIcon icon) {
		super(indexX, indexY, icon);
		setObjectType(3);  // 设置为爆炸箱子类型
		random = new Random();
	}

	/* ─── 工厂方法 ─────────────────────────────────────── */
	public static BoomBox createBox(String str) {
		// boombox,imageA,0,0,1
		String[] arr = str.split(",");
		int x = Integer.parseInt(arr[2]);
		int y = Integer.parseInt(arr[3]);
		CellBlock.setGridByIndex(y, x, 3);  // 设置箱子所在的格子类型

		ImageIcon icon = ElementFactory.ElementLoad.getInstance().getImageMap().get(arr[1]);
		return new BoomBox(x, y, icon);
	}

	/* ─── 添加道具 ─────────────────────────────────────── */
	private void addProp(int type) {
		List<SuperElement> props = ElementManager.getInstance().getElementList(PROP_LIST_KEY);
		Prop prop = Prop.createProp(getX(), getY(), type);  // 创建道具
		props.add(prop);  // 将道具添加到道具列表
	}

	/* ─── 销毁 ─────────────────────────────────────────── */
	@Override
	public void destroy() {
		if (!isVisible()) {
			ElementManager.getInstance().removeElementByPx(getY(), getX());  // 移除当前元素

			int type = random.nextInt(PROP_TYPE_COUNT);  // 随机生成道具类型
			if (type != 0) {  // 如果不是 0，则生成一个道具
				addProp(type);
			}
		}
	}

	/* ─── 显示元素 ─────────────────────────────────────── */
	@Override
	public void showElement(Graphics g) {
		g.drawImage(getImageIcon().getImage(), getX(), getY(), getW(), getH(), null);  // 绘制箱子
	}

	/* ─── 字符串输出 ───────────────────────────────────── */
	@Override
	public String toString() {
		return String.format("BoomBox [x=%d, y=%d, propType=%d, visible=%b, width=%d, height=%d]",
				getX(), getY(), getObjectType(), isVisible(), getW(), getH());
	}
}
