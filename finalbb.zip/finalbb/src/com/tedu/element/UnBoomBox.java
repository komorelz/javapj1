package com.tedu.element;

import com.tedu.manager.ElementFactory;

import javax.swing.*;
import java.awt.*;

/**
 * 不可爆炸箱子类，继承自 Box，表示不能被摧毁的箱子。
 */
public class UnBoomBox extends Box {

	/* ─── 常量 ─────────────────────────────────────────── */
	private static final int UNBOOM_BOX_TYPE = 4;  // 不可爆炸箱子的类型标识

	/* ─── 构造 ─────────────────────────────────────────── */
	public UnBoomBox(int indexX, int indexY, ImageIcon icon) {
		super(indexX, indexY, icon);
		setObjectType(UNBOOM_BOX_TYPE);  // 设置为不可爆炸箱子类型
	}

	/* ─── 显示元素 ─────────────────────────────────────── */
	@Override
	public void showElement(Graphics g) {
		g.drawImage(getImageIcon().getImage(), getX(), getY(), getW(), getH(), null);  // 绘制不可爆炸箱子
	}

	/* ─── 工厂方法 ─────────────────────────────────────── */
	public static UnBoomBox createBox(String str) {
		// unboombox,imageA,0,0,1
		String[] arr = str.split(",");
		int x = Integer.parseInt(arr[2]);
		int y = Integer.parseInt(arr[3]);

		CellBlock.setGridByIndex(y, x, UNBOOM_BOX_TYPE);  // 设置箱子所在格子的类型为不可爆炸箱子

		ImageIcon icon = ElementFactory.ElementLoad.getInstance().getImageMap().get(arr[1]);
		return new UnBoomBox(x, y, icon);
	}

	/* ─── 销毁 ─────────────────────────────────────────── */
	@Override
	public void destroy() {
		if (!isVisible()) {
			CellBlock.setGridByPx(getY(), getX(), 0);  // 清空格子的状态
		}
	}
}
