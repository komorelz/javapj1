package com.tedu.element;

import com.tedu.manager.ElementFactory;

import javax.swing.*;
import java.awt.*;

/**
 * 场景道具，可被玩家拾取；拥有 4 帧闪动动画。
 */
public class Prop extends SuperElement {

	/* ─── 常量 ─────────────────────────────────────────── */
	private static final int TILE        = 40;  // 道具大小
	private static final int FRAME_W     = 32;  // 精灵表单帧宽
	private static final int FRAME_H     = 50;  // 精灵表单帧高
	private static final int FRAME_COUNT = 4;   // 动画帧数

	/* ─── 属性 ─────────────────────────────────────────── */
	private final ImageIcon icon;   // 精灵表
	private final int propClass;    // 道具类型
	private int frameIndex = 0;     // 当前动画帧

	/* ─── 构造 ─────────────────────────────────────────── */
	private Prop(int x, int y, ImageIcon icon, int type) {
		super(x, y, TILE, TILE);
		this.icon      = icon;
		this.propClass = type;
		setObjectType(CellBlock.PROP); // 对应 CellBlock 类型 2
	}

	/** 工厂方法：根据像素坐标与道具类型创建 */
	public static Prop createProp(int x, int y, int type) {
		String key   = "imageProp" + type;
		ImageIcon img = ElementFactory.ElementLoad.getInstance()
				.getImageMap().get(key);
		return new Prop(x, y, img, type);
	}

	/* ─── 渲染 ─────────────────────────────────────────── */
	@Override
	public void showElement(Graphics g) {
		if (!isVisible()) return;

		int sx1 = FRAME_W * frameIndex;
		int sx2 = sx1 + FRAME_W;

		g.drawImage(icon.getImage(),
				getX(), getY(), getX() + getW(), getY() + getH(), // 目标区域
				sx1, 0, sx2, FRAME_H,                              // 源区域
				null);
	}

	/* ─── 逻辑更新 ─────────────────────────────────────── */
	@Override
	public void move() {
		frameIndex = (frameIndex + 1) % FRAME_COUNT; // 循环动画
	}

	@Override
	public void destroy() {
		/* 道具拾取后在外部逻辑通过 setVisible(false) + ElementManager 移除 */
	}

	@Override
	public boolean allowpass() {
		return true; // 玩家可穿过
	}

	/* ─── Getter ──────────────────────────────────────── */
	public int getPropClass() {
		return propClass;
	}
}
