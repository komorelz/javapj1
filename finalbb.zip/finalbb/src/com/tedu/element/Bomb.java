package com.tedu.element;

import com.tedu.manager.ElementManager;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class Bomb extends SuperElement {

	private static final int TILE = 40;
	private static final long EXPLODE_DURATION = 500L;

	private final ImageIcon imgR, imgL, imgT, imgD, imgC;
	private final ImageIcon imgR2, imgL2, imgT2, imgD2;

	private int numR, numL, numT, numD;
	private final long bornAt;
	private boolean flag;
	private final int id;

	public Bomb(int x, int y, int w, int h,
				ImageIcon imgC, ImageIcon imgR, ImageIcon imgL, ImageIcon imgT, ImageIcon imgD,
				ImageIcon imgR2, ImageIcon imgL2, ImageIcon imgT2, ImageIcon imgD2,
				int numR, int numL, int numT, int numD,
				int id) {

		super(x, y, w, h);
		this.imgC = imgC;
		this.imgR = imgR;
		this.imgL = imgL;
		this.imgT = imgT;
		this.imgD = imgD;
		this.imgR2 = imgR2;
		this.imgL2 = imgL2;
		this.imgT2 = imgT2;
		this.imgD2 = imgD2;

		this.numR = numR;
		this.numL = numL;
		this.numT = numT;
		this.numD = numD;

		this.flag = false;
		updateNum();
		this.bornAt = System.currentTimeMillis();
		this.id = id;
	}

	public static Bomb createBomb(int x, int y,
								  int numR, int numL, int numT, int numD,
								  int id) {

		int w = TILE;
		int h = TILE;
		String urlC = "img/bomb/C.png";
		String urlR = "img/bomb/R.png";
		String urlL = "img/bomb/L.png";
		String urlT = "img/bomb/T.png";
		String urlD = "img/bomb/D.png";
		String urlR2 = "img/bomb/R2.png";
		String urlL2 = "img/bomb/L2.png";
		String urlT2 = "img/bomb/T2.png";
		String urlD2 = "img/bomb/D2.png";

		return new Bomb(x, y, w, h,
				new ImageIcon(urlC), new ImageIcon(urlR), new ImageIcon(urlL),
				new ImageIcon(urlT), new ImageIcon(urlD),
				new ImageIcon(urlR2), new ImageIcon(urlL2),
				new ImageIcon(urlT2), new ImageIcon(urlD2),
				numR, numL, numT, numD, id);
	}

	@Override
	public void showElement(Graphics g) {
		g.drawImage(imgC.getImage(), getX(), getY(), getW(), getH(), null);

		for (int i = 0; i < numR - 1; i++)
			g.drawImage(imgR2.getImage(), getX() + (i + 1) * TILE, getY(), getW(), getH(), null);
		for (int i = 0; i < numL - 1; i++)
			g.drawImage(imgL2.getImage(), getX() - (i + 1) * TILE, getY(), getW(), getH(), null);
		for (int i = 0; i < numT - 1; i++)
			g.drawImage(imgT2.getImage(), getX(), getY() - (i + 1) * TILE, getW(), getH(), null);
		for (int i = 0; i < numD - 1; i++)
			g.drawImage(imgD2.getImage(), getX(), getY() + (i + 1) * TILE, getW(), getH(), null);

		g.drawImage(imgR.getImage(), getX() + numR * TILE, getY(), getW(), getH(), null);
		g.drawImage(imgL.getImage(), getX() - numL * TILE, getY(), getW(), getH(), null);
		g.drawImage(imgT.getImage(), getX(), getY() - numT * TILE, getW(), getH(), null);
		g.drawImage(imgD.getImage(), getX(), getY() + numD * TILE, getW(), getH(), null);
	}

	public void ruin() {
		killPlayer();

		ElementManager em = ElementManager.getInstance();
		List<SuperElement> players = em.getElementList("play");
		Player player = (Player) players.get(id);

		SuperElement center = em.getElementByPx(getY(), getX());
		if (center != null) {
			center.setVisible(false);
			em.removeElementByPx(getY(), getX());
			player.addNum(50);
		}

		clearLine(+1, 0, numR, player);
		clearLine(-1, 0, numL, player);
		clearLine(0, -1, numT, player);
		clearLine(0, +1, numD, player);
	}

	private void clearLine(int dx, int dy, int length, Player player) {
		ElementManager em = ElementManager.getInstance();
		for (int step = 1; step <= length; step++) {
			int px = getX() + dx * TILE * step;
			int py = getY() + dy * TILE * step;
			SuperElement se = em.getElementByPx(py, px);
			if (se != null) {
				se.setVisible(false);
				em.removeElementByPx(py, px);
				player.addNum(50);
			}
		}
	}

	@Override
	public void destroy() {
		if (!isVisible()) {
			CellBlock.setGridByPx(getY(), getX(), 0);
			ElementManager.getInstance().removeElementByPx(getY(), getX());
		}
	}

	@Override
	public boolean allowpass() {
		return false;
	}

	@Override
	public void move() {
		// 不可移动
	}

	@Override
	public void update() {
		super.update();
		updateTime();
		ruin();
	}

	private void updateTime() {
		if (System.currentTimeMillis() - bornAt > EXPLODE_DURATION) {
			setVisible(false);
		}
	}

	public void updateNum() {
		ElementManager em = ElementManager.getInstance();
		int r = 0, l = 0, t = 0, d = 0;

		while (r < numR && em.isBomb(getY(), getX() + TILE * (r + 1))) {
			if (em.isBoomBox(getY(), getX() + TILE * (r + 1))) {
				r++;
				break;
			}
			r++;
		}

		while (l < numL && em.isBomb(getY(), getX() - TILE * (l + 1))) {
			if (em.isBoomBox(getY(), getX() - TILE * (l + 1))) {
				l++;
				break;
			}
			l++;
		}

		while (t < numT && em.isBomb(getY() - TILE * (t + 1), getX())) {
			if (em.isBoomBox(getY() - TILE * (t + 1), getX())) {
				t++;
				break;
			}
			t++;
		}

		while (d < numD && em.isBomb(getY() + TILE * (d + 1), getX())) {
			if (em.isBoomBox(getY() + TILE * (d + 1), getX())) {
				d++;
				break;
			}
			d++;
		}

		this.numR = r;
		this.numL = l;
		this.numT = t;
		this.numD = d;
	}

	public void killPlayer() {
		if (flag) return;

		ElementManager em = ElementManager.getInstance();
		List<SuperElement> list = em.getElementList("play");

		Rectangle rectH = new Rectangle(getX() - TILE * numL, getY(), TILE * (numL + 1 + numR), TILE);
		Rectangle rectV = new Rectangle(getX(), getY() - TILE * numT, TILE, TILE * (numT + 1 + numD));

		for (SuperElement e : list) {
			Player player = (Player) e;
			Rectangle playerRec = new Rectangle(player.getX(), player.getY(), TILE, TILE);
			if (playerRec.intersects(rectH) || playerRec.intersects(rectV)) {
				player.bombByBubble(this.id);
			}
		}

		flag = true;
	}


}
