package com.tedu.game;

import com.tedu.show.GameWindow;
import com.tedu.manager.ScaleManager;

public class MainGame {
    public static void main(String[] args) {
        // 设置系统UI缩放
        System.setProperty("sun.java2d.uiScale", "1.0");

        // 初始化缩放管理器
        ScaleManager.getInstance().updateScale(ScaleManager.BASE_WIDTH, ScaleManager.BASE_HEIGHT);

        // 整个程序的入口 启动
        GameWindow gameWindow = new GameWindow();
        gameWindow.setVisible(true);
    }
}