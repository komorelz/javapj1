package com.tedu.manager;

import com.tedu.element.*;

import java.util.*;

public class ElementManager {
	private Map<String, List<SuperElement>> map;
	private SuperElement[][] objects;

	protected void init() {
		map = new HashMap<>();
		map.put("play", new ArrayList<>());
		map.put("bubble", new ArrayList<>());
		map.put("enemylist", new ArrayList<>());
		map.put("playfire", new ArrayList<>());
		map.put("box", new ArrayList<>());
		map.put("prop", new ArrayList<>());
		map.put("background", new ArrayList<>());
		map.put("bomb", new ArrayList<>());
		objects = new SuperElement[12][12];
	}

	public Map<String, List<SuperElement>> getMap() {
		return map;
	}

	public List<SuperElement> getElementList(String key) {
		return map.get(key);
	}

	private static ElementManager elementManager;

	private ElementManager() {
		init();
	}

	static {
		if (elementManager == null) {
			elementManager = new ElementManager();
		}
	}

	public static ElementManager getInstance() {
		return elementManager;
	}

	public void setElementByPx(int row, int col, SuperElement superElement) {
		objects[row / 40][col / 40] = superElement;
	}

	public SuperElement getElementByPx(int row, int col) {
		return (row < 0 || row > 440 || col < 0 || col > 440) ? null : objects[row / 40][col / 40];
	}

	public SuperElement removeElementByPx(int row, int col) {
		SuperElement superElement = getElementByPx(row, col);
		setElementByPx(row, col, null);
		return superElement;
	}

	public void load() {
		ElementFactory.ElementLoad elementLoad = ElementFactory.ElementLoad.getInstance();
		elementLoad.readImagePro();
		elementLoad.readPlayerPro();
		elementLoad.readGamePro();
		elementLoad.readBoxPro();

		SceneContext sceneContext = SceneContext.createBackground();
		map.get("background").add(sceneContext);

		Player player = (Player) ElementFactory.elementFactory("onePlayer");
		map.get("play").add(player);
		player = (Player) ElementFactory.elementFactory("twoPlayer");
		map.get("play").add(player);

		List<SuperElement> boxs = map.get("box");
		Map<String, List<String>> boxMap = elementLoad.getBoxMap();
		for (String key : boxMap.keySet()) {
			String temp = boxMap.get(key).get(0);
			String[] arr = temp.split(",");
			Box box = arr[0].equals("boombox") ? BoomBox.createBox(temp) : UnBoomBox.createBox(temp);
			boxs.add(box);
			setElementByPx(box.getY(), box.getX(), box);
		}
	}

	public void linkGame(int time) {
		List<SuperElement> players = map.get("play");
		if (players.size() < 2) return;

		Player player1 = (Player) players.get(0);
		Player player2 = (Player) players.get(1);

		if (time % 10 == 0) {
			System.out.println(player1);
			System.out.println(player2);
		}
	}

	public boolean isBomb(int row, int col) {
		SuperElement superElement = getElementByPx(row, col);
		return superElement == null || superElement.getObjectType() != 4;
	}

	public boolean isBoomBox(int row, int col) {
		SuperElement superElement = getElementByPx(row, col);
		return superElement != null && superElement.getObjectType() == 3;
	}
}