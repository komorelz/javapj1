package com.tedu.manager;


import com.tedu.element.Player;
import com.tedu.element.SuperElement;

import javax.swing.*;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.*;

import static com.tedu.show.StartFrame.globalVariable;

/*
 * 任务：
 * 依据参数不同 自动读取资源 填充VO对象 存储到元素管理器
 * 工厂的作用 将比较复杂的构造方式进行封装
 */
public class ElementFactory {

	public static SuperElement elementFactory(String name) {
		Map<String, List<String>> playMap = ElementLoad.getInstance().getPlayMap();
		Map<String, List<String>> boxMap = ElementLoad.getInstance().getBoxMap();
		List<String> gamelist = ElementLoad.getInstance().getGameList();
		switch (name) {
			case "onePlayer":
				List<String> list = playMap.get(name);
				String string = list.get(0);
				return Player.createPlayer(string);
			case "twoPlayer":
				List<String> list1 = playMap.get(name);
				String string1 = list1.get(0);
				return Player.createPlayer(string1);
			case "enemy":
				String string2 = gamelist.get(gamelist.size() - 1);
				return null; // 占位符，若有 Enemy 类需更新
			default:
				break;
		}
		return null;
	}

	public static class ElementLoad {
		private Map<String, ImageIcon> imageMap;
		private Map<String, List<String>> playMap;
		private Map<String, List<String>> enemyMap;
		private Map<String, List<String>> boxMap;
		private List<String> gameList;
		private Properties properties;

		private static ElementLoad load;

		private ElementLoad() {
			imageMap = new HashMap<>();
			playMap = new HashMap<>();
			enemyMap = new HashMap<>();
			boxMap = new HashMap<>();
			gameList = new ArrayList<>();
			properties = new Properties();
		}

		public static synchronized ElementLoad getInstance() {
			if (load == null) {
				load = new ElementLoad();
			}
			return load;
		}

		public void readBoxPro() {
			String str = "com/tedu/text/box" + globalVariable + ".pro";
			InputStream inputStream = ElementLoad.class.getClassLoader().getResourceAsStream(str);
			if (inputStream == null) {
				System.err.println("无法加载箱子配置文件: " + str);
				return;
			}
			properties.clear();
			try {
				properties.load(inputStream);
				for (Object object : properties.keySet()) {
					String string = properties.getProperty(object.toString());
					List<String> boxs = new ArrayList<>();
					boxs.add(string);
					boxMap.put(object.toString(), boxs);
				}
				System.out.println("已加载 boxMap: " + boxMap);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		public void readGamePro() {
			InputStream inputStream = ElementLoad.class.getClassLoader().getResourceAsStream("com/tedu/text/GameRunA.pro");
			properties.clear();
			try {
				properties.load(inputStream);
				for (Object object : properties.keySet()) {
					String string = properties.getProperty(object.toString());
					gameList.add(string);
				}
				System.out.println("已加载 gameList: " + gameList);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		public void readPlayerPro() {
			InputStream inputStream = ElementLoad.class.getClassLoader().getResourceAsStream("com/tedu/text/play.pro");
			try {
				properties.clear();
				properties.load(inputStream);
				for (Object object : properties.keySet()) {
					String string = properties.getProperty(object.toString());
					List<String> players = new ArrayList<>();
					players.add(string);
					playMap.put(object.toString(), players);
				}
				System.out.println("已加载 playMap: " + playMap);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		public void readImagePro() {
			String mapFile = globalVariable == 1 ? "mapA.pro" : "mapB.pro";
			InputStream inputStream = ElementLoad.class.getClassLoader().getResourceAsStream("com/tedu/text/" + mapFile);
			if (inputStream == null) {
				System.err.println("无法加载图片配置文件: com/tedu/text/" + mapFile);
				return;
			}
			try {
				properties.clear();
				properties.load(inputStream);
				Set<Object> set = properties.keySet();
				for (Object object : set) {
					String url = properties.getProperty((String) object);
					System.out.println(object + ":" + url);
					imageMap.put(object.toString(), new ImageIcon(url));
				}
				System.out.println("已加载 imageMap: " + imageMap);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		public Map<String, ImageIcon> getImageMap() {
			return imageMap;
		}

		public Map<String, List<String>> getPlayMap() {
			return playMap;
		}

		public List<String> getGameList() {
			return gameList;
		}

		public Map<String, List<String>> getBoxMap() {
			return boxMap;
		}
	}
}
