package com.tedu.element;

import com.tedu.manager.ElementFactory;
import com.tedu.show.StartFrame;

import javax.swing.*;
import java.awt.*;

public class SceneContext extends SuperElement {
	private ImageIcon icon;
	private int index;
	@Override
	public void showElement(Graphics g) {
		g.drawImage(icon.getImage(), 0, 0, 480, 480, null);
	}

	@Override
	public void move() {
		// 无移动逻辑
	}

	@Override
	public void destroy() {
		// 无销毁逻辑
	}

	public SceneContext(int x, int y, int w, int h, ImageIcon icon, int index) {
		super(x, y, w, h);
		this.icon = icon;
		this.index = index;
	}

	public static SceneContext createBackground() {
		int bgIndex = StartFrame.globalVariable == 1 ? 3 : 4; // 地图 A 用 bg3，地图 B 用 bg4
		ImageIcon icon = ElementFactory.ElementLoad.getInstance().getImageMap().get("bg" + bgIndex);
		if (icon == null) {
			System.err.println("无法加载背景图片: bg" + bgIndex);
		}
		return new SceneContext(0, 0, 480, 480, icon, bgIndex);
	}

	@Override
	public boolean allowpass() {
		return true;
	}

}
