package com.tedu.element;
public class CellBlock {
	// 0 没有 1人 2道具 3爆炸箱子 4不可爆炸箱子  5泡泡
	public static int[][] grid = new int[12][12];
	static {
		int i,j;
		for (i = 0; i < grid.length; i++) {
			for(j = 0;j <grid[i].length; j++) {
				grid[i][j]= 0; 
			}
		}
	}
	public static int getTypeByIndex(int row,int col) {
		return grid[row][col];
	}
	public static int getTypeByPx(int row,int col) {
		return grid[row/40][col/40];
	} 

	public static void setGridByPx(int row,int col,int type) {
		grid[row/40][col/40] = type;
	}
	public static void setGridByIndex(int row,int col,int type) {
		grid[row][col] = type;
	}

}
