package com.tedu.element;

import javax.swing.*;
import java.awt.*;


public class Box extends SuperElement {
	private int indexX,indexY;
	private ImageIcon imageIcon;

	public Box() {

	}



	public Box(int indexX, int indexY, ImageIcon icon) {
		super();
		this.indexX = indexX;
		this.indexY = indexY;
		this.imageIcon = icon;

		setX(indexX*40);
		setY(indexY*40);
		setW(40);
		setH(40);
	}


	@Override
	public void showElement(Graphics g) {
		// TODO 自动生成的方法存根

	}

	@Override
	public void move() {
		// TODO 自动生成的方法存根

	}

	@Override
	public void destroy() {
		// TODO 自动生成的方法存根

	}

	@Override
	public boolean allowpass() {
		return false;
	}

	public int getIndexX() {
		return indexX;
	}

	public int getIndexY() {
		return indexY;
	}

	public ImageIcon getImageIcon() {
		return imageIcon;
	}


}
