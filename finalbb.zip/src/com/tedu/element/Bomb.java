package com.tedu.element;

import com.tedu.manager.ElementManager;

import javax.swing.*;
import java.awt.*;
import java.util.Calendar;
import java.util.List;

public class Bomb extends SuperElement{
	private ImageIcon imgR ;
	private ImageIcon imgL ;
	private ImageIcon imgT ;
	private ImageIcon imgD ;
	private ImageIcon imgC ;
	private ImageIcon imgR2 ;
	private ImageIcon imgL2 ;
	private ImageIcon imgT2 ;
	private ImageIcon imgD2 ;
	private int numR ;
	private int numL ;
	private int numT ;
	private int numD ;
	private Calendar cal;
	private boolean flag;
	private int id;
	public Bomb(int x, int y, int w, int h, ImageIcon imgC, ImageIcon imgR, ImageIcon imgL, ImageIcon imgT, ImageIcon imgD,
                ImageIcon imgR2, ImageIcon imgL2, ImageIcon imgT2, ImageIcon imgD2, int numR, int numL, int numT, int numD, int id) {
		super(x, y, w, h);
		this.imgC = imgC;
		this.imgR = imgR;
		this.imgL = imgL;
		this.imgT = imgT;
		this.imgD = imgD;
		this.imgR2 = imgR2;
		this.imgL2 = imgL2;
		this.imgT2 = imgT2;
		this.imgD2 = imgD2;

		this.numR = numR;
		this.numL = numL;
		this.numT = numT;
		this.numD = numD;
		flag = false;
		updateNum();		
		this.cal = Calendar.getInstance();
		this.id = id;
	}



	public static Bomb createBomb(int x,int y,int numR,int numL,int numT,int numD,int id) {


		int w = 40;
		int h = 40;
		String urlC = "img/bomb/C.png";
		String urlR = "img/bomb/R.png";
		String urlL = "img/bomb/L.png";
		String urlT = "img/bomb/T.png";
		String urlD = "img/bomb/D.png";
		String urlR2 = "img/bomb/R2.png";
		String urlL2 = "img/bomb/L2.png";
		String urlT2 = "img/bomb/T2.png";
		String urlD2 = "img/bomb/D2.png";

		ImageIcon imgR =new ImageIcon(urlR);
		ImageIcon imgL =new ImageIcon(urlL);
		ImageIcon imgT =new ImageIcon(urlT);
		ImageIcon imgD =new ImageIcon(urlD);
		ImageIcon imgR2 =new ImageIcon(urlR2);
		ImageIcon imgL2 =new ImageIcon(urlL2);
		ImageIcon imgT2 =new ImageIcon(urlT2);
		ImageIcon imgD2 =new ImageIcon(urlD2);
		ImageIcon imgC = new ImageIcon(urlC);

		return new Bomb(x,y,w,h, imgC,imgR,  imgL,  imgT,  imgD,
				imgR2,  imgL2,  imgT2,  imgD2,numR,numL,numT,numD,id);
	}
	@Override
	public void showElement(Graphics g) {

		g.drawImage(imgC.getImage(), getX(), getY(), getW(),getH(),null);
		for(int i=0;i<numR-1;i++) {
			g.drawImage(imgR2.getImage(), getX()+(i+1)*40, getY(), getW(), getH(), null);

		}
		for(int i=0;i<numL-1;i++) {
			g.drawImage(imgL2.getImage(), getX()-(i+1)*40, getY(), getW(), getH(), null);

		}
		for(int i=0;i<numT-1;i++) {
			g.drawImage(imgT2.getImage(), getX(), getY()-(i+1)*40, getW(), getH(), null);

		}
		for(int i=0;i<numD-1;i++) {
			g.drawImage(imgD2.getImage(), getX(), getY()+(i+1)*40, getW(), getH(), null);

		}
		g.drawImage(imgR.getImage(), getX()+numR*40,getY(),getW(),getH(), null);
		g.drawImage(imgL.getImage(), getX()-numL*40,getY(),getW(),getH(), null);
		g.drawImage(imgT.getImage(), getX(),getY()-numT*40,getW(),getH(), null);
		g.drawImage(imgD.getImage(), getX(),getY()+numD*40,getW(),getH(), null);		
	}


	public void ruin() {
		killPlayer();
		System.out.println("左："+numL+"   右："+numR);
		List<SuperElement> players = ElementManager.getInstance().getElementList("play");
		Player player = (Player)players.get(id);  // 通过id获取对应的玩家

		SuperElement s = ElementManager.getInstance().getElementByPx(getY(), getX());
		if(s!=null) {
			s.setVisible(false);
			ElementManager.getInstance().removeElementByPx(getY(), getX());
			player.addNum(50);
		}

		for(int i=0;i<numR;i++) {
			SuperElement se = ElementManager.getInstance().getElementByPx(getY(), getX()+(i+1)*40);
			if(se!=null) {
				se.setVisible(false);
				ElementManager.getInstance().removeElementByPx(getY(), getX()+(i+1)*40);
				player.addNum(50);
			}
		}
		for(int i=0;i<numL;i++) {
			SuperElement se = ElementManager.getInstance().getElementByPx(getY(), getX()-(i+1)*40);

			if(se!=null) {
				se.setVisible(false);
				ElementManager.getInstance().removeElementByPx(getY(), getX()-(i+1)*40);
				player.addNum(50);
			}
		}
		for(int i=0;i<numT;i++) {
			SuperElement se = ElementManager.getInstance().getElementByPx(getY()-(i+1)*40, getX());
			if(se!=null) {
				se.setVisible(false);
				ElementManager.getInstance().removeElementByPx(getY()-(i+1)*40, getX());
				player.addNum(50);
			}
		}
		for(int i=0;i<numD;i++) {
			SuperElement se = ElementManager.getInstance().getElementByPx(getY()+(i+1)*40, getX());
			if(se!=null) {
				se.setVisible(false);
				ElementManager.getInstance().removeElementByPx(getY()+(i+1)*40, getX());
				player.addNum(50);
			}
		}


	}
	@Override
	public void destroy() {
		if (!isVisible()) {
			CellBlock.setGridByPx(getY(), getX(), 0);
			ElementManager.getInstance().removeElementByPx(getY(), getX());
		}
	}

	@Override
	public boolean allowpass() {
		return false;
	}

	@Override
	public void move() {
		// TODO 自动生成的方法存根

	}
	public void update() {
		super.update();
		updateTime();

		ruin();
	}
	public void updateNum() {
		int r =0;
		for(;r<this.numR&&ElementManager.getInstance().isBomb(getY(),getX()+40*(r+1));r++)
			if(ElementManager.getInstance().isBoomBox(getY(),getX()+40*(r+1))) {
				r++;
				break;
			}
		int l =0;
		for(;l<this.numL&&ElementManager.getInstance().isBomb(getY(),getX()-40*(l+1));l++)
			if(ElementManager.getInstance().isBoomBox(getY(),getX()-40*(l+1))) {
				l++;
				break;
			}
		int t =0;
		for(;t<this.numT&&ElementManager.getInstance().isBomb(getY()-40*(t+1),getX());t++)
			if(ElementManager.getInstance().isBoomBox(getY()-40*(t+1),getX())) {
				t++;
				break;
			}
		int d =0;
		for(;d<this.numD&&ElementManager.getInstance().isBomb(getY()+40*(d+1),getX());d++)
			if(ElementManager.getInstance().isBoomBox(getY()+40*(d+1),getX())) {
				d++;
				break;
			}

		this.numR = r;
		this.numL = l;
		this.numT = t;
		this.numD = d;
	}


	public void killPlayer() {
		if(flag) return ;
		List<SuperElement> list = ElementManager.getInstance().getElementList("play");
		for(int i=0;i<2;i++) {
			Player player = (Player)list.get(i);
			Rectangle rectangle = new Rectangle(getX()-40*numL,getY(),40*(numL+1+numR),40);
			Rectangle playerRec = new Rectangle(player.getX(),player.getY(),40,40);
			if (playerRec.intersects(rectangle)) {
				player.bombByBubble(this.id);
				continue;
			}
			rectangle = new Rectangle(getX(),getY()-numT*40,40,40*(numD+numT));
			if (playerRec.intersects(rectangle)) {
				player.bombByBubble(this.id);
			}
		}
		flag =true;

	}

	public void updateTime() {
		Calendar calendar = Calendar.getInstance();
		if (calendar.getTime().getTime()-500>this.cal.getTime().getTime()) {
			setVisible(false);
		}
	}




	@Override
	public String toString() {
		return "Bomb [id=" + id + "]";
	}

}
