package com.tedu.element;

import com.tedu.manager.ElementFactory;

import javax.swing.*;
import java.awt.*;

public class Prop extends SuperElement {
	private ImageIcon icon;
	private int propClass;//道具类型
	private int moveX;

	public Prop(int x, int y, int w, int h, ImageIcon icon, int type) {
		super(x, y, w, h);
		this.icon = icon;
		this.propClass = type;
		setObjectType(2);
	}
	public static Prop createProp(int x,int y,int type) {
		String url = "imageProp"+type;
		ImageIcon icon = ElementFactory.ElementLoad.getInstance().getImageMap().get(url);
		Prop prop = new Prop(x, y, 40, 40, icon, type);
		return prop;
	}
	@Override
	public void showElement(Graphics g) {
		g.drawImage(icon.getImage(), getX(), getY(), getX()+getW(), getY()+getH(),
				0+32*moveX, 0,
				32+32*moveX, 50,
				null);

	}

	@Override
	public void move() {
		moveX = (++moveX)%4;
	}

	@Override
	public void destroy() {
	}
	public int getPropClass() {
		return propClass;
	}

	@Override
	public boolean allowpass() {
		return true;
	}
}
