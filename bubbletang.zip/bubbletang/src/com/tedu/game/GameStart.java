package com.tedu.game;

import com.tedu.show.StartFrame;
import com.tedu.manager.ScaleManager;

public class GameStart {
    public static void main(String[] args) {
        // 设置系统UI缩放
        System.setProperty("sun.java2d.uiScale", "1.0");

        // 初始化缩放管理器
        ScaleManager.getInstance().updateScale(ScaleManager.BASE_WIDTH, ScaleManager.BASE_HEIGHT);

        // 整个程序的入口 启动
        StartFrame startFrame = new StartFrame();
        startFrame.setVisible(true);
    }
}