package com.tedu.manager;

import com.tedu.element.*;

import java.util.*;

public class ElementManager {
	// 集合 NPC元素 场景元素
	private Map<String, List<SuperElement>> map;
	private SuperElement[][] objects;

	// 初始化
	protected void init() {
		map = new HashMap<>();
		map.put("play", new ArrayList<>());
		map.put("bubble", new ArrayList<>());
		map.put("enemylist", new ArrayList<>());
		map.put("playfire", new ArrayList<>());
		map.put("box", new ArrayList<>());
		map.put("prop", new ArrayList<>());
		map.put("background", new ArrayList<>());
		map.put("bomb", new ArrayList<>());
		objects = new SuperElement[12][12];
	}

	// 获取map集合
	public Map<String, List<SuperElement>> getMap() {
		return map;
	}

	// 获取元素集合
	public List<SuperElement> getElementList(String key) {
		return map.get(key);
	}

	// 单例：唯一引用
	private static ElementManager elementManager;

	private ElementManager() {
		init();
	}

	static {
		if (elementManager == null) {
			elementManager = new ElementManager();
		}
	}

	// 获取实例
	public static ElementManager getInstance() {
		return elementManager;
	}

	// 设置元素
	public void setElementByPx(int row, int col, SuperElement superElement) {
		objects[row / 40][col / 40] = superElement;
	}

	public void setElementByIndex(int row, int col, SuperElement superElement) {
		objects[row][col] = superElement;
	}

	// 获取元素
	public SuperElement getElementByPx(int row, int col) {
		return (row < 0 || row > 440 || col < 0 || col > 440) ? null : objects[row / 40][col / 40];
	}

	public SuperElement getElementByIndex(int row, int col) {
		return objects[row][col];
	}

	// 移除元素
	public SuperElement removeElementByPx(int row, int col) {
		SuperElement superElement = getElementByPx(row, col);
		setElementByPx(row, col, null);
		return superElement;
	}

	public SuperElement removeElementByIndex(int row, int col) {
		SuperElement superElement = getElementByIndex(row, col);
		setElementByIndex(row, col, null);
		return superElement;
	}

	// 更新元素
	public void updateElementByPx(int preRow, int currentRow, int preCol, int currentCol) {
		setElementByPx(currentRow, currentCol, removeElementByPx(preRow, preCol));
	}

	public void updateElementByIndex(int preRow, int currentRow, int preCol, int currentCol) {
		setElementByIndex(currentRow, currentCol, removeElementByIndex(preRow, preCol));
	}

	// 资源加载
	public void load() {
		ElementFactory.ElementLoad elementLoad = ElementFactory.ElementLoad.getInstance();
		elementLoad.readImagePro();
		elementLoad.readPlayerPro();
		elementLoad.readGamePro();
		elementLoad.readBoxPro();

		SceneContext sceneContext = SceneContext.createBackground(2);
		map.get("background").add(sceneContext);

		Player player = (Player) ElementFactory.elementFactory("onePlayer");
		map.get("play").add(player);
		player = (Player) ElementFactory.elementFactory("twoPlayer");
		map.get("play").add(player);

		List<SuperElement> boxs = map.get("box");
		Map<String, List<String>> boxMap = elementLoad.getBoxMap();
		for (String key : boxMap.keySet()) {
			String temp = boxMap.get(key).get(0);
			String[] arr = temp.split(",");
			Box box = arr[0].equals("boombox") ? BoomBox.createBox(temp) : UnBoomBox.createBox(temp);
			boxs.add(box);
			setElementByPx(box.getY(), box.getX(), box);
		}
	}

	// 控制流程
	public void linkGame(int time) {
		List<SuperElement> players = map.get("play");
		if (players.size() < 2) return;

		Player player1 = (Player) players.get(0);
		Player player2 = (Player) players.get(1);

		if (time % 10 == 0) {
			System.out.println(player1);
			System.out.println(player2);
		}
	}

	// 判断是否可以通过
	public boolean isAllowPassByPx(int row, int col) {
		SuperElement superElement = getElementByPx(row, col);
		return superElement == null || superElement.getObjectType() <= 2;
	}

	public boolean isAllowPassByIndex(int row, int col) {
		SuperElement superElement = getElementByIndex(row, col);
		return superElement == null || superElement.getObjectType() <= 2;
	}

	// 输出状态
	public void cout() {
		for (int i = 0; i < 12; i++) {
			for (int j = 0; j < 12; j++) {
				SuperElement superElement = getElementByIndex(i, j);
				System.out.print((superElement != null ? superElement.getObjectType() : 0) + " ");
			}
			System.out.println();
		}
	}

	// 获取对象数组
	public SuperElement[][] getObjects() {
		return objects;
	}

	public void setObjects(SuperElement[][] objects) {
		this.objects = objects;
	}

	// 判断是否为炸弹
	public boolean isBomb(int row, int col) {
		SuperElement superElement = getElementByPx(row, col);
		return superElement == null || superElement.getObjectType() != 4;
	}

	// 判断是否为炸弹箱
	public boolean isBoomBox(int row, int col) {
		SuperElement superElement = getElementByPx(row, col);
		return superElement != null && superElement.getObjectType() == 3;
	}
}
