package com.tedu.manager;

import java.awt.*;

public class ScaleManager {
    // 基础分辨率
    public static final int BASE_WIDTH = 960;
    public static final int BASE_HEIGHT = 720;

    // 当前窗口分辨率
    private static int currentWidth = BASE_WIDTH;
    private static int currentHeight = BASE_HEIGHT;

    // 缩放比例
    private static double scaleX = 1.0;
    private static double scaleY = 1.0;

    // 单例实例
    private static ScaleManager instance;

    private ScaleManager() {}

    public static ScaleManager getInstance() {
        if (instance == null) {
            instance = new ScaleManager();
        }
        return instance;
    }

    // 更新当前分辨率和缩放比例
    public void updateScale(int width, int height) {
        currentWidth = width;
        currentHeight = height;
        scaleX = (double) width / BASE_WIDTH;
        scaleY = (double) height / BASE_HEIGHT;
    }

    // 获取缩放后的X坐标
    public int scaleX(int x) {
        return (int) (x * scaleX);
    }

    // 获取缩放后的Y坐标
    public int scaleY(int y) {
        return (int) (y * scaleY);
    }

    // 获取缩放后的宽度
    public int scaleWidth(int width) {
        return (int) (width * scaleX);
    }

    // 获取缩放后的高度
    public int scaleHeight(int height) {
        return (int) (height * scaleY);
    }

    // 获取缩放后的字体大小
    public int scaleFontSize(int fontSize) {
        return (int) (fontSize * Math.min(scaleX, scaleY));
    }

    // 缩放Graphics对象
    public void scaleGraphics(Graphics2D g2d) {
        g2d.scale(scaleX, scaleY);
    }

    // 将像素坐标转换为网格坐标（考虑缩放）
    public int pixelToGrid(int pixel) {
        return (int) (pixel / (40 * Math.min(scaleX, scaleY)));
    }

    // 将网格坐标转换为像素坐标（考虑缩放）
    public int gridToPixel(int grid) {
        return (int) (grid * 40 * Math.min(scaleX, scaleY));
    }

    // Getter方法
    public double getScaleX() { return scaleX; }
    public double getScaleY() { return scaleY; }
    public int getCurrentWidth() { return currentWidth; }
    public int getCurrentHeight() { return currentHeight; }
}