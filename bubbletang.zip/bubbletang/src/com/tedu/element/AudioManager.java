package com.tedu.element;

import java.applet.Applet;
import java.applet.AudioClip;
import java.io.File;
import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

import javax.sound.sampled.*;
import java.io.IOException;

public class AudioManager {

	// 音频文件路径常量
	public static final String ADD = "music/put.wav";     // 坦克诞生音效
	public static final String BGM = "music/bgm_1.wav";   // bgm音效
	public static final String BOOM = "music/boom.wav";   // 爆炸音效
	public static final String OVER = "music/gameover.wav"; // 结束音效

	// 单例模式
	private static AudioManager instance;
	private ConcurrentHashMap<String, AudioPlayer> audioPlayers;

	private AudioManager() {
		audioPlayers = new ConcurrentHashMap<>();
	}

	public static AudioManager getInstance() {
		if (instance == null) {
			synchronized (AudioManager.class) {
				if (instance == null) {
					instance = new AudioManager();
				}
			}
		}
		return instance;
	}

	// 原Audio类的方法 - 使用AudioClip播放音效
	public static List<AudioClip> getAudios() {
		List<AudioClip> audios = new ArrayList<>();
		try {
			audios.add(Applet.newAudioClip(((new File(BGM)).toURI()).toURL()));
			audios.add(Applet.newAudioClip(((new File(ADD)).toURI()).toURL()));
			audios.add(Applet.newAudioClip(((new File(BOOM)).toURI()).toURL()));
			audios.add(Applet.newAudioClip(((new File(OVER)).toURI()).toURL()));
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
		return audios;
	}

	// 播放音效（使用AudioClip，适合短音效）
	public void playSound(String audioPath) {
		try {
			AudioClip clip = Applet.newAudioClip(((new File(audioPath)).toURI()).toURL());
			clip.play();
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
	}

	// 播放背景音乐（使用AudioPlayer，适合长音乐）
	public void playBackgroundMusic(String audioPath) {
		playBackgroundMusic(audioPath, false);
	}

	// 播放背景音乐（支持循环播放）
	public void playBackgroundMusic(String audioPath, boolean loop) {
		// 停止之前的背景音乐
		stopBackgroundMusic();

		AudioPlayer player = new AudioPlayer(audioPath, loop);
		audioPlayers.put("bgm", player);

		Thread playThread = new Thread(player::play);
		playThread.setDaemon(true);
		playThread.start();
	}

	// 停止背景音乐
	public void stopBackgroundMusic() {
		AudioPlayer player = audioPlayers.get("bgm");
		if (player != null) {
			player.stop();
			audioPlayers.remove("bgm");
		}
	}

	// 播放指定名称的音频
	public void playAudio(String name, String audioPath) {
		playAudio(name, audioPath, false);
	}

	// 播放指定名称的音频（支持循环播放）
	public void playAudio(String name, String audioPath, boolean loop) {
		// 如果已经在播放，先停止
		stopAudio(name);

		AudioPlayer player = new AudioPlayer(audioPath, loop);
		audioPlayers.put(name, player);

		Thread playThread = new Thread(player::play);
		playThread.setDaemon(true);
		playThread.start();
	}

	// 停止指定名称的音频
	public void stopAudio(String name) {
		AudioPlayer player = audioPlayers.get(name);
		if (player != null) {
			player.stop();
			audioPlayers.remove(name);
		}
	}

	// 停止所有音频
	public void stopAllAudios() {
		for (AudioPlayer player : audioPlayers.values()) {
			player.stop();
		}
		audioPlayers.clear();
	}

	// 内部类 - 音频播放器（基于原audioPlay类）
	private static class AudioPlayer {
		private String fileName;
		private AudioInputStream audioInputStream;
		private AudioFormat format;
		private DataLine.Info info;
		private SourceDataLine line;
		private boolean stop = false;
		private boolean loop = false;

		public AudioPlayer(String fileName) {
			this(fileName, false);
		}

		public AudioPlayer(String fileName, boolean loop) {
			this.fileName = fileName;
			this.loop = loop;
		}

		@SuppressWarnings("deprecation")
		public void play() {
			do {
				try {
					audioInputStream = AudioSystem.getAudioInputStream(new File(fileName).toURI().toURL());
					format = audioInputStream.getFormat();
					info = new DataLine.Info(SourceDataLine.class, format);
					line = (SourceDataLine) AudioSystem.getLine(info);

					line.open(format);
					line.start();

					int len = 0;
					byte[] buffer = new byte[512];

					while (!stop) {
						len = audioInputStream.read(buffer, 0, buffer.length);
						if (len <= 0) {
							break;
						}
						line.write(buffer, 0, len);
					}

					line.drain();
					line.close();

					if (audioInputStream != null) {
						audioInputStream.close();
					}

				} catch (IOException e) {
					e.printStackTrace();
					break;
				} catch (LineUnavailableException e) {
					e.printStackTrace();
					break;
				} catch (UnsupportedAudioFileException e) {
					e.printStackTrace();
					break;
				}
			} while (loop && !stop);
		}

		public void stop() {
			stop = true;
			if (line != null) {
				line.stop();
			}
		}

		public boolean isPlaying() {
			return line != null && line.isRunning();
		}
	}

	// 便利方法 - 直接播放预定义的音效
	public void playPutSound() {
		playSound(ADD);
	}

	public void playBoomSound() {
		playSound(BOOM);
	}

	public void playGameOverSound() {
		playSound(OVER);
	}

	public void playBGM() {
		playBackgroundMusic(BGM, true);
	}

	// 检查音频是否正在播放
	public boolean isPlaying(String name) {
		AudioPlayer player = audioPlayers.get(name);
		return player != null && player.isPlaying();
	}

	// 资源清理
	public void dispose() {
		stopAllAudios();
	}
}