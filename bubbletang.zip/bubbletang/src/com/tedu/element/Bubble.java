package com.tedu.element;

import com.tedu.manager.ElementManager;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class Bubble extends SuperElement {
	private ImageIcon img;
	private int moveX;
	private int id;
	private Calendar creationTime;
	private int power;

	// 泡泡存在时间（毫秒）
	private static final int BUBBLE_LIFETIME = 2000;

	// 动画帧数
	private static final int ANIMATION_FRAMES = 4;

	// 图片尺寸常量
	private static final int SPRITE_WIDTH = 32;
	private static final int SPRITE_HEIGHT = 40;
	private static final int SPRITE_Y_OFFSET = 6;

	public Bubble() {
		super();
	}

	public Bubble(int x, int y, int w, int h, ImageIcon icon, int id, int power) {
		super(x, y, w, h);
		this.img = icon;
		this.id = id;
		this.power = power;
		this.creationTime = Calendar.getInstance();
		this.moveX = 0;
		setObjectType(5);
	}

	/**
	 * 创建泡泡的静态工厂方法
	 */
	public static Bubble createBubble(int x, int y, ImageIcon icon, int id, int power) {
		return new Bubble(x, y, 40, 40, icon, id, power);
	}

	/**
	 * 获取泡泡所有者ID
	 */
	public int getOwnerId() {
		return this.id;
	}

	@Override
	public void showElement(Graphics g) {
		if (img == null) return;

		// 计算精灵图中的位置
		int spriteX = SPRITE_WIDTH * moveX;
		int spriteY = SPRITE_Y_OFFSET;

		// 绘制泡泡动画
		g.drawImage(img.getImage(),
				getX(), getY(), // 屏幕左上角坐标
				getX() + getW(), getY() + getH(), // 屏幕右下角坐标
				spriteX, spriteY, // 图片左上角坐标
				spriteX + SPRITE_WIDTH, spriteY + SPRITE_HEIGHT, // 图片右下角坐标
				null);
	}

	@Override
	public void move() {
		// 泡泡不移动，但可以在这里添加特殊移动逻辑
	}

	@Override
	public void destroy() {
		if (!isVisible()) {
			// 使用改进的AudioManager播放爆炸音效
			playExplosionSound();

			// 清除网格中的泡泡
			clearFromGrid();

			// 减少玩家当前泡泡数量
			updatePlayerBubbleCount();

			// 创建爆炸效果
			createExplosion();
		}
	}

	/**
	 * 播放爆炸音效
	 */
	private void playExplosionSound() {
		new Thread(() -> {
			AudioManager.getInstance().playBoomSound();
		}).start();
	}

	/**
	 * 从网格中清除泡泡
	 */
	private void clearFromGrid() {
		CellBlock.setGridByPx(getY(), getX(), 0);
		ElementManager.getInstance().removeElementByPx(getY(), getX());
	}

	/**
	 * 更新玩家泡泡数量
	 */
	private void updatePlayerBubbleCount() {
		try {
			List<SuperElement> playerList = ElementManager.getInstance().getElementList("play");
			if (playerList != null && id < playerList.size()) {
				Player player = (Player) playerList.get(id);
				int currentBubbles = player.getCurrentBubble();
				player.setCurrentBubble(currentBubbles - 1);
			}
		} catch (Exception e) {
			System.err.println("Error updating player bubble count: " + e.getMessage());
		}
	}

	/**
	 * 创建爆炸效果
	 */
	private void createExplosion() {
		List<SuperElement> bombList = ElementManager.getInstance().getElementList("bomb");
		if (bombList == null) {
			bombList = new ArrayList<>();
		}

		Bomb bomb = Bomb.createBomb(getX(), getY(), power, power, power, power, id);
		bombList.add(bomb);
		ElementManager.getInstance().setElementByPx(getY(), getX(), bomb);

		System.out.println("Bubble exploded, created bomb: " + bomb);
	}

	@Override
	public void update() {
		super.update();
		updateLifetime();
		updateAnimation();
	}

	/**
	 * 更新泡泡生存时间
	 */
	private void updateLifetime() {
		Calendar currentTime = Calendar.getInstance();
		long elapsedTime = currentTime.getTimeInMillis() - creationTime.getTimeInMillis();

		if (elapsedTime > BUBBLE_LIFETIME) {
			setVisible(false);
			destroy();
		}
	}

	/**
	 * 更新动画帧
	 */
	private void updateAnimation() {
		moveX = (moveX + 1) % ANIMATION_FRAMES;
	}

	@Override
	public boolean allowpass() {
		return false; // 泡泡不允许通过
	}

	// Getter 和 Setter 方法
	public ImageIcon getImg() {
		return img;
	}

	public void setImg(ImageIcon img) {
		this.img = img;
	}

	public int getPower() {
		return power;
	}

	public void setPower(int power) {
		this.power = power;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	/**
	 * 获取剩余生存时间（毫秒）
	 */
	public long getRemainingLifetime() {
		Calendar currentTime = Calendar.getInstance();
		long elapsedTime = currentTime.getTimeInMillis() - creationTime.getTimeInMillis();
		return Math.max(0, BUBBLE_LIFETIME - elapsedTime);
	}

	/**
	 * 检查泡泡是否即将爆炸
	 */
	public boolean isAboutToExplode() {
		return getRemainingLifetime() < 500; // 剩余时间少于500毫秒
	}

	@Override
	public String toString() {
		return String.format("Bubble[id=%d, power=%d, pos=(%d,%d), remaining=%dms]",
				id, power, getX(), getY(), getRemainingLifetime());
	}
}