package com.tedu.element;

import com.tedu.manager.ElementFactory;

import javax.swing.*;
import java.awt.*;

public class SceneContext extends SuperElement {
	private ImageIcon icon;
	private int index;
	@Override
	public void showElement(Graphics g) {

		g.drawImage(icon.getImage(), 0, 0, 480, 480, null);
	}

	@Override
	public void move() {

	}

	@Override
	public void destroy() {

	}

	public SceneContext() {
		super();
	}

	public SceneContext(int x, int y, int w, int h, ImageIcon icon, int index) {
		super(x, y, w, h);
		this.icon = icon;
		this.index = index;
	}
	public static SceneContext createBackground(int index) {
		ImageIcon icon = ElementFactory.ElementLoad.getInstance().getImageMap().get("bg"+index);
		return new SceneContext(0, 0, 480, 480, icon,index);
	}

	public ImageIcon getIcon() {
		return icon;
	}

	public void setIcon(ImageIcon icon) {
		this.icon = icon;
	}

	public int getIndex() {
		return index;
	}

	public void setIndex(int index) {
		this.index = index;
	}

	@Override
	public boolean allowpass() {
		// TODO 自动生成的方法存根
		return true;
	}
	
}
