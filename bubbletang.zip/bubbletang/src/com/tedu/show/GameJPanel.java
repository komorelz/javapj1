package com.tedu.show;

import java.awt.*;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

import com.tedu.manager.ElementManager;
import com.tedu.manager.ScaleManager;
import com.tedu.element.Player;
import com.tedu.element.SuperElement;

public class GameJPanel extends JPanel implements Runnable {
    private ElementManager manager;
    private ScaleManager scaleManager;
    private JButton restartButton;
    private boolean gameOver = false;
    private volatile boolean running = true;

    // 倒计时相关变量
    private long gameStartTime;
    private static final long GAME_DURATION_MS = 2 * 60 * 1000; // 2分钟
    private long remainingTime = GAME_DURATION_MS;
    private boolean timeUp = false;

    // 预加载的图片
    private BufferedImage rightSightImage;
    private BufferedImage bottomImage;
    private BufferedImage gameOverImage;

    // 布局比例 - 基于原始设计尺寸
    private static final int ORIGINAL_GAME_WIDTH = 480;
    private static final int ORIGINAL_GAME_HEIGHT = 480;
    private static final int ORIGINAL_RIGHT_PANEL_WIDTH = 160;
    private static final int ORIGINAL_BOTTOM_PANEL_HEIGHT = 50;
    private static final int ORIGINAL_TOTAL_WIDTH = ORIGINAL_GAME_WIDTH + ORIGINAL_RIGHT_PANEL_WIDTH;
    private static final int ORIGINAL_TOTAL_HEIGHT = ORIGINAL_GAME_HEIGHT + ORIGINAL_BOTTOM_PANEL_HEIGHT;

    public GameJPanel() {
        setLayout(null);
        setDoubleBuffered(true);
        setOpaque(true);
        setBackground(Color.BLACK);

        manager = ElementManager.getInstance();
        scaleManager = ScaleManager.getInstance();

        // 初始化游戏开始时间
        gameStartTime = System.currentTimeMillis();

        // 预加载图片
        loadImages();

        // 创建重新开始按钮
        initRestartButton();
    }

    @Override
    public void setBounds(int x, int y, int width, int height) {
        super.setBounds(x, y, width, height);
        // 当面板大小改变时，更新按钮位置
        if (restartButton != null) {
            updateRestartButtonSize();
        }
    }

    private void loadImages() {
        // 加载右侧背景图
        try {
            File rightSightFile = new File("img/bg/right_sight.png");
            if (rightSightFile.exists()) {
                rightSightImage = ImageIO.read(rightSightFile);
                System.out.println("右侧背景图片加载成功: " + rightSightFile.getAbsolutePath());
            } else {
                System.out.println("右侧背景图片不存在: " + rightSightFile.getAbsolutePath());
                rightSightImage = createPlaceholderImage(ORIGINAL_RIGHT_PANEL_WIDTH, ORIGINAL_TOTAL_HEIGHT, Color.CYAN);
            }
        } catch (IOException e) {
            System.err.println("加载右侧背景图片失败: " + e.getMessage());
            rightSightImage = createPlaceholderImage(ORIGINAL_RIGHT_PANEL_WIDTH, ORIGINAL_TOTAL_HEIGHT, Color.CYAN);
        }

        // 加载底部背景图
        try {
            File bottomFile = new File("img/bg/bottom.png");
            if (bottomFile.exists()) {
                bottomImage = ImageIO.read(bottomFile);
                System.out.println("底部背景图片加载成功: " + bottomFile.getAbsolutePath());
            } else {
                System.out.println("底部背景图片不存在: " + bottomFile.getAbsolutePath());
                bottomImage = createPlaceholderImage(ORIGINAL_GAME_WIDTH, ORIGINAL_BOTTOM_PANEL_HEIGHT, Color.ORANGE);
            }
        } catch (IOException e) {
            System.err.println("加载底部背景图片失败: " + e.getMessage());
            bottomImage = createPlaceholderImage(ORIGINAL_GAME_WIDTH, ORIGINAL_BOTTOM_PANEL_HEIGHT, Color.ORANGE);
        }

        // 加载游戏结束背景图
        try {
            File gameOverFile = new File("img/bg/gameovers.png");
            if (gameOverFile.exists()) {
                gameOverImage = ImageIO.read(gameOverFile);
                System.out.println("游戏结束背景图片加载成功: " + gameOverFile.getAbsolutePath());
            } else {
                System.out.println("游戏结束背景图片不存在: " + gameOverFile.getAbsolutePath());
                gameOverImage = createPlaceholderImage(ORIGINAL_TOTAL_WIDTH, ORIGINAL_TOTAL_HEIGHT, Color.DARK_GRAY);
            }
        } catch (IOException e) {
            System.err.println("加载游戏结束背景图片失败: " + e.getMessage());
            gameOverImage = createPlaceholderImage(ORIGINAL_TOTAL_WIDTH, ORIGINAL_TOTAL_HEIGHT, Color.DARK_GRAY);
        }

        System.out.println("当前工作目录: " + System.getProperty("user.dir"));
    }

    private BufferedImage createPlaceholderImage(int width, int height, Color color) {
        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        Graphics2D g2d = image.createGraphics();
        g2d.setColor(color);
        g2d.fillRect(0, 0, width, height);
        g2d.setColor(Color.BLACK);
        g2d.drawRect(0, 0, width - 1, height - 1);
        g2d.setColor(Color.WHITE);
        g2d.drawString("占位图片", width / 2 - 20, height / 2);
        g2d.dispose();
        return image;
    }

    private void initRestartButton() {
        restartButton = new JButton(" ");
        restartButton.setIcon(new ImageIcon("img/bg/gameover.jpg"));

        // 设置按钮样式
        restartButton.setContentAreaFilled(false);
        restartButton.setBorderPainted(false);
        restartButton.setFocusPainted(false);
        restartButton.setHorizontalTextPosition(JButton.CENTER);
        restartButton.setVerticalTextPosition(JButton.CENTER);
        restartButton.setForeground(Color.WHITE);
        restartButton.setFont(new Font("宋体", Font.BOLD, 16));

        restartButton.addActionListener(e -> restartGame());
        add(restartButton);
        restartButton.setVisible(false);
        updateRestartButtonSize();
    }

    private void updateRestartButtonSize() {
        int panelWidth = getWidth();
        int panelHeight = getHeight();

        if (panelWidth > 0 && panelHeight > 0) {
            // 计算按钮大小和位置，放在中间偏下位置
            int buttonWidth = Math.max(200, panelWidth / 4);
            int buttonHeight = Math.max(60, panelHeight / 10);
            int buttonX = (panelWidth - buttonWidth) / 2;
            int buttonY = (int) (panelHeight * 0.8); // 80%的高度位置

            restartButton.setBounds(buttonX, buttonY, buttonWidth, buttonHeight);

            // 缩放按钮图标
            ImageIcon originalIcon = new ImageIcon("img/bg/gameover.jpg");
            Image scaledImage = originalIcon.getImage().getScaledInstance(
                    buttonWidth, buttonHeight, Image.SCALE_SMOOTH);
            restartButton.setIcon(new ImageIcon(scaledImage));

            // 调整字体大小
            int fontSize = Math.max(14, Math.min(panelWidth, panelHeight) / 35);
            restartButton.setFont(new Font("宋体", Font.BOLD, fontSize));
        }
    }

    /**
     * 更新倒计时
     */
    private void updateCountdown() {
        if (!gameOver && !timeUp) {
            long currentTime = System.currentTimeMillis();
            long elapsedTime = currentTime - gameStartTime;
            remainingTime = GAME_DURATION_MS - elapsedTime;

            if (remainingTime <= 0) {
                remainingTime = 0;
                timeUp = true;
                gameOver = true;
            }
        }
    }

    /**
     * 格式化倒计时显示
     */
    private String formatTime(long timeInMs) {
        long seconds = timeInMs / 1000;
        long minutes = seconds / 60;
        seconds = seconds % 60;
        return String.format("%02d:%02d", minutes, seconds);
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);

        Graphics2D g2d = (Graphics2D) g.create();
        setupGraphics(g2d);

        try {
            // 更新倒计时
            updateCountdown();

            // 计算缩放比例
            double scaleX = (double) getWidth() / ORIGINAL_TOTAL_WIDTH;
            double scaleY = (double) getHeight() / ORIGINAL_TOTAL_HEIGHT;

            // 绘制游戏内容
            if (!gameOver) {
                drawGameContent(g2d, scaleX, scaleY);
            }

            // 绘制UI面板
            drawUIPanels(g2d, scaleX, scaleY);

            // 绘制倒计时
            drawCountdown(g2d, scaleX, scaleY);

            // 绘制分数
            drawScores(g2d, scaleX, scaleY);

            // 检查并处理游戏结束
            handleGameOver(g2d, scaleX, scaleY);

        } finally {
            g2d.dispose();
        }
    }

    private void setupGraphics(Graphics2D g2d) {
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
    }

    private void drawGameContent(Graphics2D g2d, double scaleX, double scaleY) {
        // 计算游戏区域的实际尺寸（填满整个可用区域）
        int gameAreaWidth = (int) (ORIGINAL_GAME_WIDTH * scaleX);
        int gameAreaHeight = (int) (ORIGINAL_GAME_HEIGHT * scaleY);

        // 绘制游戏区域背景
        g2d.setColor(Color.WHITE);
        g2d.fillRect(0, 0, gameAreaWidth, gameAreaHeight);

        // 保存当前变换
        AffineTransform originalTransform = g2d.getTransform();

        try {
            // 设置游戏区域的缩放和裁剪
            g2d.setClip(0, 0, gameAreaWidth, gameAreaHeight);

            // 应用缩放变换到游戏元素
            g2d.scale(scaleX, scaleY);

            // 绘制游戏元素
            Map<String, List<SuperElement>> map = manager.getMap();
            Set<String> keys = map.keySet();
            List<String> sortedKeys = new ArrayList<>(keys);
            Collections.sort(sortedKeys);

            for (String key : sortedKeys) {
                List<SuperElement> elements = map.get(key);
                for (SuperElement element : elements) {
                    element.showElement(g2d);
                }
            }
        } finally {
            // 恢复原始变换和裁剪
            g2d.setTransform(originalTransform);
            g2d.setClip(null);
        }
    }

    private void drawUIPanels(Graphics2D g2d, double scaleX, double scaleY) {
        // 计算各区域尺寸
        int gameAreaWidth = (int) (ORIGINAL_GAME_WIDTH * scaleX);
        int gameAreaHeight = (int) (ORIGINAL_GAME_HEIGHT * scaleY);
        int rightPanelWidth = (int) (ORIGINAL_RIGHT_PANEL_WIDTH * scaleX);
        int bottomPanelHeight = (int) (ORIGINAL_BOTTOM_PANEL_HEIGHT * scaleY);
        int totalHeight = (int) (ORIGINAL_TOTAL_HEIGHT * scaleY);

        // 绘制右侧面板
        if (rightSightImage != null) {
            g2d.drawImage(rightSightImage,
                    gameAreaWidth, 0, rightPanelWidth, totalHeight,
                    this);
        } else {
            g2d.setColor(Color.CYAN);
            g2d.fillRect(gameAreaWidth, 0, rightPanelWidth, totalHeight);
        }

        // 绘制底部面板
        if (bottomImage != null) {
            g2d.drawImage(bottomImage,
                    0, gameAreaHeight, gameAreaWidth, bottomPanelHeight,
                    this);
        } else {
            g2d.setColor(Color.ORANGE);
            g2d.fillRect(0, gameAreaHeight, gameAreaWidth, bottomPanelHeight);
        }
    }

    /**
     * 绘制倒计时
     */
    private void drawCountdown(Graphics2D g2d, double scaleX, double scaleY) {
        // 计算字体大小和位置
        int fontSize = Math.max(14, (int) (20 * Math.min(scaleX, scaleY)));
        Font countdownFont = new Font("宋体", Font.BOLD, fontSize);
        g2d.setFont(countdownFont);

        // 根据剩余时间设置颜色
        if (remainingTime > 30000) { // 超过30秒，显示绿色
            g2d.setColor(Color.GREEN);
        } else if (remainingTime > 10000) { // 超过10秒，显示黄色
            g2d.setColor(Color.YELLOW);
        } else { // 少于10秒，显示红色
            g2d.setColor(Color.RED);
        }

        int rightPanelX = (int) (ORIGINAL_GAME_WIDTH * scaleX) + 110;
        int countdownY = (int) (30 * scaleY);

        String timeText = formatTime(remainingTime);
        g2d.drawString(timeText, rightPanelX, countdownY);
    }

    private void drawScores(Graphics2D g2d, double scaleX, double scaleY) {
        List<SuperElement> playerList = manager.getElementList("play");
        if (playerList != null && playerList.size() >= 2) {
            // 计算字体大小和位置
            int fontSize = Math.max(12, (int) (18 * Math.min(scaleX, scaleY)));
            Font scoreFont = new Font("宋体", Font.BOLD, fontSize);
            g2d.setFont(scoreFont);
            g2d.setColor(Color.BLACK);

            int rightPanelX = (int) (ORIGINAL_GAME_WIDTH * scaleX) + 100;
            int player1Y = (int) (70 * scaleY)-10; // 调整位置，给倒计时留出空间
            int player2Y = (int) (95 * scaleY)+20;

            // 绘制P1分数
            Player player1 = (Player) playerList.get(0);
            if (player1 != null) {
                String p1Score = "P1: " + player1.getNum();
                g2d.drawString(p1Score, rightPanelX, player1Y);
            }

            // 绘制P2分数
            Player player2 = (Player) playerList.get(1);
            if (player2 != null) {
                String p2Score = "P2: " + player2.getNum();
                g2d.drawString(p2Score, rightPanelX, player2Y);
            }
        }
    }

    private void handleGameOver(Graphics2D g2d, double scaleX, double scaleY) {
        // 检查游戏结束条件
        if (!gameOver) {
            List<SuperElement> playerList = manager.getElementList("play");
            if (playerList != null && playerList.size() >= 2) {
                Player player1 = (Player) playerList.get(0);
                Player player2 = (Player) playerList.get(1);

                // 检查是否有玩家达到1000分或时间到了
                if ((player1 != null && player1.getNum() >= 1000) ||
                        (player2 != null && player2.getNum() >= 1000) ||
                        timeUp) {
                    gameOver = true;
                    updateRestartButtonSize();
                }
            }
        }

        // 如果游戏结束，绘制游戏结束界面
        if (gameOver) {
            drawGameOverScreen(g2d, scaleX, scaleY);
        }
    }

    private void drawGameOverScreen(Graphics2D g2d, double scaleX, double scaleY) {
        // 绘制游戏结束背景
        if (gameOverImage != null) {
            g2d.drawImage(gameOverImage, 0, 0, getWidth(), getHeight(), this);
        } else {
            g2d.setColor(Color.DARK_GRAY);
            g2d.fillRect(0, 0, getWidth(), getHeight());
        }

        // 绘制胜利文本 - 放在中间偏上的位置
        String winnerText = determineWinner();
        int fontSize = Math.max(24, (int) (36 * Math.min(scaleX, scaleY)));
        Font winnerFont = new Font("宋体", Font.BOLD, fontSize);
        g2d.setFont(winnerFont);
        g2d.setColor(Color.YELLOW);

        FontMetrics fm = g2d.getFontMetrics();
        int textWidth = fm.stringWidth(winnerText);
        int textX = (getWidth() - textWidth) / 2;
        int textY = (int) (getHeight() * 0.6); // 60%的高度位置

        // 添加文字阴影效果
        g2d.setColor(Color.BLACK);
        g2d.drawString(winnerText, textX + 2, textY + 2);
        g2d.setColor(Color.YELLOW);
        g2d.drawString(winnerText, textX, textY);

        // 显示重新开始按钮
        if (!restartButton.isVisible()) {
            restartButton.setVisible(true);
            setComponentZOrder(restartButton, 0);
        }
    }

    private String determineWinner() {
        List<SuperElement> playerList = manager.getElementList("play");
        if (playerList != null && playerList.size() >= 2) {
            Player player1 = (Player) playerList.get(0);
            Player player2 = (Player) playerList.get(1);

            if (player1 != null && player2 != null) {
                // 如果时间到了，比较分数
                if (timeUp) {
                    int p1Score = player1.getNum();
                    int p2Score = player2.getNum();

                    if (p1Score > p2Score) {
                        return "时间到! 1P 胜利! (分数: " + p1Score + ")";
                    } else if (p2Score > p1Score) {
                        return "时间到! 2P 胜利! (分数: " + p2Score + ")";
                    } else {
                        return "时间到! 平局! (分数: " + p1Score + ")";
                    }
                }
                // 如果有玩家达到1000分
                else if (player1.getNum() >= 1000) {
                    return "1P 胜利! (率先达到1000分)";
                } else if (player2.getNum() >= 1000) {
                    return "2P 胜利! (率先达到1000分)";
                }
            }
        }
        return "游戏结束";
    }

    private void restartGame() {
        gameOver = false;
        timeUp = false;
        remainingTime = GAME_DURATION_MS;
        gameStartTime = System.currentTimeMillis();
        restartButton.setVisible(false);
        running = false;

        GameJFrame gameJFrame = (GameJFrame) SwingUtilities.getWindowAncestor(this);
        SwingUtilities.invokeLater(() -> {
            if (gameJFrame != null) {
                gameJFrame.dispose();
            }
            try {
                StartFrame startFrame = new StartFrame();
                startFrame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
                resetCurrentGame();
            }
        });
    }

    private void resetCurrentGame() {
        gameOver = false;
        timeUp = false;
        remainingTime = GAME_DURATION_MS;
        gameStartTime = System.currentTimeMillis();
        restartButton.setVisible(false);
        running = true;
        repaint();
    }

    public void stopGame() {
        running = false;
    }

    @Override
    public void run() {
        while (running) {
            try {
                TimeUnit.MILLISECONDS.sleep(16); // 60 FPS
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                break;
            }

            if (running) {
                SwingUtilities.invokeLater(this::repaint);
            }
        }
    }
}