package com.tedu.show;

import com.tedu.controller.GameListener;
import com.tedu.manager.ScaleManager;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;

public class StartFrame extends JFrame implements ActionListener {
    public static int globalVariable = 10;
    private JPanel contentPane;
    private JComboBox<String> mapSelector;
    private JButton startButton;
    private JLabel backgroundLabel;
    private ScaleManager scaleManager;

    public StartFrame() {
        scaleManager = ScaleManager.getInstance();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        contentPane = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g.create();
                g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
                g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
                g2d.dispose();
            }
        };
        setContentPane(contentPane);
        this.getRootPane().setWindowDecorationStyle(JRootPane.NONE);
        this.setResizable(true);

        // 初始大小
        setSize(ScaleManager.BASE_WIDTH, ScaleManager.BASE_HEIGHT);
        setTitle("泡泡堂");
        this.setLocationRelativeTo(null);

        // 添加组件调整监听器
        addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                onResize();
            }
        });

        init();
    }

    private void onResize() {
        Dimension size = getSize();
        scaleManager.updateScale(size.width, size.height);
        updateComponentSizes();
        repaint();
    }

    private void updateComponentSizes() {
        if (mapSelector != null) {
            // 将地图选择框放在窗口中间偏下位置
            int centerX = scaleManager.getCurrentWidth() / 2;
            int lowerY = (int) (scaleManager.getCurrentHeight() * 0.65); // 65%的高度位置

            mapSelector.setBounds(
                    centerX - scaleManager.scaleWidth(75), // 居中对齐
                    lowerY,
                    scaleManager.scaleWidth(150),
                    scaleManager.scaleHeight(30)
            );
            mapSelector.setFont(new Font("宋体", Font.PLAIN, scaleManager.scaleFontSize(14)));
        }

        if (startButton != null) {
            // 将开始游戏按钮放在地图选择框下方
            int centerX = scaleManager.getCurrentWidth() / 2;
            int lowerY = (int) (scaleManager.getCurrentHeight() * 0.75); // 75%的高度位置

            startButton.setBounds(
                    centerX - scaleManager.scaleWidth(135), // 居中对齐
                    lowerY,
                    scaleManager.scaleWidth(270),
                    scaleManager.scaleHeight(80)
            );

            // 缩放按钮图标
            ImageIcon originalIcon = new ImageIcon("img/bg/startgame.png");
            Image scaledImage = originalIcon.getImage().getScaledInstance(
                    scaleManager.scaleWidth(270),
                    scaleManager.scaleHeight(80),
                    Image.SCALE_SMOOTH
            );
            startButton.setIcon(new ImageIcon(scaledImage));
        }

        if (backgroundLabel != null) {
            backgroundLabel.setBounds(0, 0, scaleManager.getCurrentWidth(), scaleManager.getCurrentHeight());

            // 缩放背景图片
            ImageIcon originalBg = new ImageIcon("img/bg/start.png");
            Image scaledBg = originalBg.getImage().getScaledInstance(
                    scaleManager.getCurrentWidth(),
                    scaleManager.getCurrentHeight(),
                    Image.SCALE_SMOOTH
            );
            backgroundLabel.setIcon(new ImageIcon(scaledBg));
        }
    }

    public void init() {
        contentPane.setLayout(null);

        // 创建地图选择下拉框
        String[] mapOptions = {"地图 A", "地图 B"};
        mapSelector = new JComboBox<>(mapOptions);

        // 初始位置设置为窗口中间偏下
        int centerX = ScaleManager.BASE_WIDTH / 2;
        int lowerY = (int) (ScaleManager.BASE_HEIGHT * 0.65);

        mapSelector.setBounds(
                centerX - scaleManager.scaleWidth(75), // 居中对齐
                lowerY,
                scaleManager.scaleWidth(150),
                scaleManager.scaleHeight(30)
        );
        mapSelector.setFont(new Font("宋体", Font.PLAIN, scaleManager.scaleFontSize(14)));
        contentPane.add(mapSelector);

        // 创建开始游戏按钮
        startButton = new JButton("开始游戏");
        startButton.setIcon(new ImageIcon("img/bg/startgame.png"));

        // 将按钮放在地图选择框下方
        int buttonY = (int) (ScaleManager.BASE_HEIGHT * 0.75);

        startButton.setBounds(
                centerX - scaleManager.scaleWidth(135), // 居中对齐
                buttonY,
                scaleManager.scaleWidth(270),
                scaleManager.scaleHeight(80)
        );
        startButton.setContentAreaFilled(false);
        startButton.setBorderPainted(false);
        startButton.setFocusPainted(false);
        contentPane.add(startButton);

        // 背景标签
        backgroundLabel = new JLabel();
        backgroundLabel.setIcon(new ImageIcon("img/bg/start.png"));
        backgroundLabel.setBounds(0, 0, ScaleManager.BASE_WIDTH, ScaleManager.BASE_HEIGHT);
        contentPane.add(backgroundLabel);

        startButton.addActionListener(this);

        // 初始化组件大小
        updateComponentSizes();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        // 获取用户选择的地图
        String selectedMap = (String) mapSelector.getSelectedItem();

        // 隐藏当前界面
        this.setVisible(false);

        // 根据选择的地图加载相应的资源
        if ("地图 A".equals(selectedMap)) {
            globalVariable = 1;
        } else if ("地图 B".equals(selectedMap)) {
            globalVariable = 0;
        }

        // 显示过渡界面
        TransitionFrame transitionFrame = new TransitionFrame();
        transitionFrame.setVisible(true);

        // 过渡界面显示一段时间后，启动游戏界面
        Timer timer = new Timer(6000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                SwingUtilities.invokeLater(() -> {
                    transitionFrame.dispose();

                    // 启动游戏界面
                    GameJFrame gameJFrame = new GameJFrame();
                    GameJPanel gameJPanel = new GameJPanel();
                    GameListener gameListener = new GameListener();

                    gameJFrame.setKeyListener(gameListener);
                    gameJFrame.addListener();
                    gameJFrame.setJPanel(gameJPanel);
                    gameJFrame.addJPanel();
                    gameJFrame.start();
                });
            }
        });
        timer.setRepeats(false);
        timer.start();

        // 清理当前窗口
        this.dispose();
    }
}