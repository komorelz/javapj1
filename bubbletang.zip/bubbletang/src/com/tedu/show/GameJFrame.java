package com.tedu.show;

import com.tedu.controller.GameThread;
import com.tedu.manager.ScaleManager;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

public class GameJFrame extends JFrame {
    private KeyListener keyListener;
    private MouseListener mouseListener;
    private MouseMotionListener mouseMotionListener;
    private JPanel jPanel;
    private ScaleManager scaleManager;

    public GameJFrame() {
        super();
        scaleManager = ScaleManager.getInstance();
        init();
    }

    //初始化方法
    public void init(){
        this.setTitle("泡泡堂");
        this.setSize(scaleManager.getCurrentWidth(), scaleManager.getCurrentHeight());
        this.setResizable(true);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);

        // 添加组件调整监听器
        addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                onResize();
            }
        });
    }

    private void onResize() {
        Dimension size = getSize();
        scaleManager.updateScale(size.width, size.height);
        if (jPanel != null) {
            jPanel.setSize(size);
            jPanel.revalidate();
            jPanel.repaint();
        }
    }

    //绑定监听
    public void addListener(){
        if (keyListener!=null) {
            this.addKeyListener(keyListener);
        }
        if (mouseListener!=null) {
            this.addMouseListener(mouseListener);
        }
        if (mouseMotionListener!=null) {
            this.addMouseMotionListener(mouseMotionListener);
        }
    }

    //画板绑定
    public void addJPanel(){
        if (jPanel!=null) {
            this.add(jPanel);
        }
    }

    public void start(){
        //窗体显示
        this.setVisible(true);
        //线程启动
        if (jPanel instanceof Runnable) {
            new Thread((Runnable)jPanel).start();
        }
        GameThread gameThread = new GameThread();
        gameThread.start();
    }

    //set注入
    public void setKeyListener(KeyListener keyListener) {
        this.keyListener = keyListener;
    }

    public void setMouseListener(MouseListener mouseListener) {
        this.mouseListener = mouseListener;
    }

    public void setMouseMotionListener(MouseMotionListener mouseMotionListener) {
        this.mouseMotionListener = mouseMotionListener;
    }

    public void setJPanel(JPanel jPanel){
        this.jPanel = jPanel;
    }
}