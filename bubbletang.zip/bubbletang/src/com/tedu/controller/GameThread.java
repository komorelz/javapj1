package com.tedu.controller;

import com.tedu.manager.ElementManager;
import com.tedu.element.Player;
import com.tedu.element.SuperElement;
import com.tedu.element.AudioManager;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;

// java线程类 的实现 通过内部类弥补单继承的缺陷

public class GameThread extends Thread {
	// 计时数据
	private static int time;
	private boolean flag = true;
	private AudioManager audioManager;

	public GameThread() {
		audioManager = AudioManager.getInstance();
	}

	// 重构老项目
	@Override
	public void run() {
		loadElement();

		time = 0;
		loadBGM();
		runGame();

		try {
			TimeUnit.MILLISECONDS.sleep(150);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	// 控制进度 但是作为控制 请不要接触load 只能通过元素管理器访问元素
	public void loadElement() {
		ElementManager.getInstance().load();
	}

	public void runGame() {
		// 这个循环控制每个关卡 地图中玩的状态
		ElementManager manager = ElementManager.getInstance();
		while (flag) {
			Map<String, List<SuperElement>> map = manager.getMap();
			Set<String> set = map.keySet();
			List<String> temp = new ArrayList<>();
			temp.addAll(set);
			// 迭代器在遍历的过程中，迭代器中的元素不可以变化(增加或减少)
			for (int i = temp.size() - 1; i >= 0; i--) {
				List<SuperElement> list = map.get(temp.get(i));
				for (int j = 0; j < list.size(); j++) {
					SuperElement superElement = list.get(j);
					superElement.update();
					if (!superElement.isVisible()) {
						manager.removeElementByPx(superElement.getY(), superElement.getX());
						list.remove(j);
					}
				}
			}
			// 使用一个独立的方法来进行判定
			PK();

			// 游戏的流程控制
			linkGame();

			try {
				TimeUnit.MILLISECONDS.sleep(100);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			// 死亡 通关状态 结束runGame方法
			overGame();

			time++; // 一秒钟增加10
		}

		// 游戏结束时清理音频资源
		audioManager.stopAllAudios();
	}

	public void PK() {
		List<SuperElement> players = ElementManager.getInstance().getElementList("play");
		List<SuperElement> enemys = ElementManager.getInstance().getElementList("enemylist");
		// 进行比较
		listPK(players, enemys);
	}

	public void listPK(List<SuperElement> list1, List<SuperElement> list2) {
		for (int i = 0; i < list1.size(); i++) {
			for (int j = 0; j < list2.size(); j++) {
				if (list1.get(i).gamePK(list2.get(j))) {
					list2.get(j).setVisible(false);
					// 播放爆炸音效
					audioManager.playBoomSound();
				}
			}
		}
	}

	public void overGame() {
		Player player1 = (Player) (ElementManager.getInstance().getElementList("play").get(0));
		Player player2 = (Player) (ElementManager.getInstance().getElementList("play").get(1));
		if (player1.getNum() >= 1000 || player2.getNum() >= 1000) {
			flag = false;
			// 停止背景音乐
			audioManager.stopBackgroundMusic();
			// 播放游戏结束音效
			audioManager.playGameOverSound();
		}
	}

	// 游戏的流程控制
	public void linkGame() {
		ElementManager.getInstance().linkGame(time);
	}

	public static int getTime() {
		return time;
	}

	public static void setTime(int time) {
		GameThread.time = time;
	}

	private void loadBGM() {
		// 使用新的AudioManager播放背景音乐（循环播放）
		audioManager.playBGM();
	}

	// 停止游戏线程
	public void stopGame() {
		flag = false;
		audioManager.stopAllAudios();
	}

	// 暂停/恢复背景音乐
	public void pauseBGM() {
		audioManager.stopBackgroundMusic();
	}

	public void resumeBGM() {
		if (flag) {
			audioManager.playBGM();
		}
	}

	// 播放坦克诞生音效
	public void playTankSpawnSound() {
		audioManager.playPutSound();
	}

	// 获取音频管理器实例（供其他类使用）
	public AudioManager getAudioManager() {
		return audioManager;
	}
}